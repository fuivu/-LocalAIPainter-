// Top-level build file
buildscript {
    repositories {
        google()
        mavenCentral()
    }
    dependencies {
        classpath("com.android.tools.build:gradle:8.5.2")
        classpath("org.jetbrains.kotlin:kotlin-gradle-plugin:2.0.20")
        classpath("com.google.devtools.ksp:symbol-processing-gradle-plugin:2.0.20-1.0.25")
    }
}

allprojects {
    repositories {
        google()
        mavenCentral()
        maven { url = uri("https://jitpack.io") }
    }
}

tasks.register("clean", Delete::class) {
    delete(rootProject.buildDir)
}

// 全局属性
extra["compileSdk"] = 34
extra["minSdk"] = 26
extra["targetSdk"] = 34
extra["kotlinVersion"] = "2.0.20"
extra["composeBomVersion"] = "2024.08.00"
extra["coroutinesVersion"] = "1.8.1"
extra["viewModelVersion"] = "2.8.4"
extra["navigationVersion"] = "2.7.7"
extra["dataStoreVersion"] = "1.1.1"
extra["mnnVersion"] = "2.7.0"
extra["ncnnVersion"] = "20240820"
extra["onnxRuntimeVersion"] = "1.18.0"
