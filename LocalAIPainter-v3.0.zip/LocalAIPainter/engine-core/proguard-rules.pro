# engine-core ProGuard Rules
-keep class com.localaipainter.engine.** { *; }
-keep class com.localaipainter.core.** { *; }
-keepclasseswithmembernames class * {
    native <methods>;
}
-dontwarn com.localaipainter.engine.**
