package com.localaipainter.engine

/**
 * 人脸修复模型类型
 */
enum class FaceRestoreType(val value: Int, val displayName: String, val quality: String) {
    GFPGAN(JNIBridge.FACE_GFPGAN, "GFPGAN", "自然写实"),
    CODEFORMER(JNIBridge.FACE_CODEFORMER, "CodeFormer", "细节丰富"),
    RESTOREFORMER(JNIBridge.FACE_RESTOREFORMER, "RestoreFormer", "高清修复");

    companion object {
        fun fromValue(value: Int): FaceRestoreType {
            return values().find { it.value == value } ?: GFPGAN
        }
    }
}
