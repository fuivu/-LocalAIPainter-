package com.localaipainter.engine

import android.os.Build
import android.os.Debug
import android.content.Context
import android.app.ActivityManager

/**
 * 设备信息检测
 */
data class DeviceInfo(
    val bestBackend: String,
    val hasGpu: Boolean,
    val totalRamMB: Long,
    val availableRamMB: Long,
    val gpuMemoryMB: Long,
    val cpuCores: Int,
    val cpuModel: String,
    val androidVersion: String,
    val sdkVersion: Int
) {
    val recommendedMaxResolution: Int
        get() = when {
            totalRamMB >= 12000 && hasGpu -> 1024
            totalRamMB >= 8000 -> 768
            totalRamMB >= 4000 -> 512
            else -> 384
        }

    val recommendedSteps: Int
        get() = if (bestBackend == "gpu" || bestBackend == "npu") 30 else 20

    companion object {
        fun detect(context: Context, engineId: Int): DeviceInfo {
            val am = context.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
            val memInfo = ActivityManager.MemoryInfo()
            am.getMemoryInfo(memInfo)

            val totalRam = memInfo.totalMem / (1024 * 1024)
            val availRam = memInfo.availMem / (1024 * 1024)

            val backend = JNIBridge.nativeGetBestBackend(engineId)
            val hasGpu = JNIBridge.nativeHasGpu()

            val memArray = IntArray(3)
            JNIBridge.nativeGetMemoryInfo(memArray)
            val gpuMem = if (memArray[2] > 0) memArray[2].toLong() else 0L

            return DeviceInfo(
                bestBackend = backend,
                hasGpu = hasGpu,
                totalRamMB = totalRam,
                availableRamMB = availRam,
                gpuMemoryMB = gpuMem,
                cpuCores = Runtime.getRuntime().availableProcessors(),
                cpuModel = Build.HARDWARE,
                androidVersion = Build.VERSION.RELEASE,
                sdkVersion = Build.VERSION.SDK_INT
            )
        }
    }
}
