package com.localaipainter.engine

import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow

/**
 * 进度回调适配器 - 将 JNI 回调桥接到 Kotlin Flow
 */
class ProgressAdapter : JNIBridge.ProgressCallback {

    private val _progress = MutableStateFlow(0f)
    val progress: StateFlow<Float> = _progress

    private val _currentStep = MutableStateFlow(0)
    val currentStep: StateFlow<Int> = _currentStep

    private val _totalSteps = MutableStateFlow(0)
    val totalSteps: StateFlow<Int> = _totalSteps

    private val _etaSeconds = MutableStateFlow(0.0)
    val etaSeconds: StateFlow<Double> = _etaSeconds

    private val _isGenerating = MutableStateFlow(false)
    val isGenerating: StateFlow<Boolean> = _isGenerating

    fun start(totalSteps: Int) {
        _isGenerating.value = true
        _totalSteps.value = totalSteps
        _currentStep.value = 0
        _progress.value = 0f
        _etaSeconds.value = 0.0
    }

    fun stop() {
        _isGenerating.value = false
    }

    override fun onProgress(step: Int, totalSteps: Int, progress: Double, etaSeconds: Double) {
        _currentStep.value = step
        _totalSteps.value = totalSteps
        _progress.value = progress.toFloat()
        _etaSeconds.value = etaSeconds
    }
}
