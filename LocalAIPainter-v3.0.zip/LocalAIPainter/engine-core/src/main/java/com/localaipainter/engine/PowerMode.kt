package com.localaipainter.engine

/**
 * 性能模式
 */
enum class PowerMode(val displayName: String, val description: String) {
    ECO("省电模式", "仅CPU推理，降低线程数，限制分辨率"),
    BALANCED("均衡模式", "智能选择GPU/CPU，平衡速度与功耗"),
    PERFORMANCE("性能模式", "全力GPU/NPU推理，最高分辨率"),
    ULTRA("极限模式", "解除所有限制，最大显存占用，最高质量");

    fun maxResolution(): Int = when (this) {
        ECO -> 384
        BALANCED -> 768
        PERFORMANCE -> 1024
        ULTRA -> 2048
    }

    fun maxThreads(): Int = when (this) {
        ECO -> 2
        BALANCED -> 4
        PERFORMANCE -> 8
        ULTRA -> Runtime.getRuntime().availableProcessors()
    }

    fun useGpu(): Boolean = this != ECO

    fun useQuantization(): Boolean = this == ECO || this == BALANCED
}
