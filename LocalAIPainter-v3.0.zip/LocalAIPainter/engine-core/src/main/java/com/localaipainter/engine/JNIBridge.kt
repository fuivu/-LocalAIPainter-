package com.localaipainter.engine

/**
 * JNI Bridge - Kotlin 侧接口
 * 对应 C++ 端的 jni_bridge.cpp
 */
object JNIBridge {

    init {
        System.loadLibrary("engine_factory")
    }

    // ============ 生命周期 ============

    external fun nativeInit(context: Any, modelDir: String): Int
    external fun nativeDestroy(engineId: Int)
    external fun nativeLoadModel(engineId: Int, modelPath: String, modelType: Int): Boolean

    // ============ 配置 ============

    external fun nativeSetScheduler(engineId: Int, schedulerType: Int)
    external fun nativeSetSteps(engineId: Int, steps: Int)
    external fun nativeSetCfgScale(engineId: Int, cfg: Float)
    external fun nativeSetSeed(engineId: Int, seed: Long)
    external fun nativeSetResolution(engineId: Int, width: Int, height: Int)
    external fun nativeSetClipSkip(engineId: Int, skip: Int)
    external fun nativeSetBatchSize(engineId: Int, batch: Int)
    external fun nativeSetDenoisingStrength(engineId: Int, strength: Float)

    // ============ 推理 ============

    external fun nativeGenerate(
        engineId: Int,
        prompt: String,
        negativePrompt: String,
        outputPath: String
    ): Boolean

    external fun nativeGenerateImageToImage(
        engineId: Int,
        prompt: String,
        negativePrompt: String,
        inputImagePath: String,
        strength: Float,
        outputPath: String
    ): Boolean

    external fun nativeStop(engineId: Int)

    // ============ 进度回调 ============

    external fun nativeSetProgressCallback(callback: ProgressCallback?)

    interface ProgressCallback {
        fun onProgress(step: Int, totalSteps: Int, progress: Double, etaSeconds: Double)
    }

    // ============ LoRA ============

    external fun nativeLoadLora(engineId: Int, loraPath: String, weight: Float): Boolean
    external fun nativeUnloadLora(engineId: Int, loraName: String)
    external fun nativeSetLoraWeight(engineId: Int, loraName: String, weight: Float)

    // ============ ControlNet ============

    external fun nativeLoadControlNet(engineId: Int, controlnetPath: String, controlType: Int): Boolean
    external fun nativeSetControlImage(engineId: Int, imagePath: String, strength: Float)

    // ============ 超分 ============

    external fun nativeUpscale(
        engineId: Int,
        inputPath: String,
        outputPath: String,
        scale: Int
    ): Boolean

    // ============ 人脸修复 ============

    external fun nativeRestoreFace(
        engineId: Int,
        inputPath: String,
        outputPath: String,
        modelType: Int
    ): Boolean

    // ============ 设备检测 ============

    external fun nativeGetBestBackend(engineId: Int): String
    external fun nativeHasGpu(): Boolean
    external fun nativeGetMemoryInfo(outInfo: IntArray): Int

    // ============ 模型管理 ============

    external fun nativeValidateModel(modelPath: String): Boolean
    external fun nativeGetModelInfo(modelPath: String): String

    // ============ 性能统计 ============

    external fun nativeGetPerfStats(engineId: Int): String

    // ============ 常量 ============

    // ModelType
    const val MODEL_SD15 = 0
    const val MODEL_SD21 = 1
    const val MODEL_SDXL = 2
    const val MODEL_LCM = 3
    const val MODEL_PIXART = 4
    const val MODEL_KOLORS = 5

    // SchedulerType
    const val SCHEDULER_EULER_A = 0
    const val SCHEDULER_EULER = 1
    const val SCHEDULER_DPM_PP_2M = 2
    const val SCHEDULER_DPM_PP_2M_KARRAS = 3
    const val SCHEDULER_DPM_PP_2S_ANCESTRAL = 4
    const val SCHEDULER_LCM = 5
    const val SCHEDULER_UNIPC = 6
    const val SCHEDULER_HEUN = 7
    const val SCHEDULER_DDIM = 8
    const val SCHEDULER_PLMS = 9

    // ControlNetType
    const val CONTROL_CANNY = 0
    const val CONTROL_OPENPOSE = 1
    const val CONTROL_DEPTH = 2
    const val CONTROL_SCRIBBLE = 3
    const val CONTROL_MLSD = 4
    const val CONTROL_SEG = 5

    // FaceRestoreType
    const val FACE_GFPGAN = 0
    const val FACE_CODEFORMER = 1
    const val FACE_RESTOREFORMER = 2
}
