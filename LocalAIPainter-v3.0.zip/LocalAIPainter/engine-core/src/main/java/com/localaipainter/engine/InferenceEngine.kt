package com.localaipainter.engine

import android.content.Context
import com.localaipainter.models.LoRAModel
import com.localaipainter.models.ControlNetModel
import kotlinx.coroutines.flow.StateFlow

/**
 * 推理引擎接口 - 统一抽象层
 * 所有后端（MNN/NCNN/ONNX/CPU）实现此接口
 */
interface InferenceEngine {

    val engineId: Int
    val isReady: StateFlow<Boolean>
    val progress: StateFlow<Float>

    // ============ 生命周期 ============

    fun init(context: Context, modelDir: String): Boolean
    fun loadModel(path: String, type: ModelType): Boolean
    fun shutdown()

    // ============ 配置 ============

    fun setScheduler(type: SchedulerType)
    fun setSteps(steps: Int)
    fun setCfgScale(cfg: Float)
    fun setSeed(seed: Long)
    fun setResolution(width: Int, height: Int)
    fun setClipSkip(skip: Int)
    fun setBatchSize(batch: Int)
    fun setDenoisingStrength(strength: Float)

    // ============ 推理 ============

    suspend fun generate(
        prompt: String,
        negativePrompt: String,
        outputPath: String
    ): Boolean

    suspend fun generateImageToImage(
        prompt: String,
        negativePrompt: String,
        inputImagePath: String,
        strength: Float,
        outputPath: String
    ): Boolean

    fun stop()

    // ============ LoRA ============

    fun loadLora(path: String, weight: Float): Boolean
    fun unloadLora(name: String)
    fun setLoraWeight(name: String, weight: Float)

    // ============ ControlNet ============

    fun loadControlNet(path: String, type: ControlNetType): Boolean
    fun setControlImage(path: String, strength: Float)

    // ============ 后处理 ============

    fun upscale(inputPath: String, outputPath: String, scale: Int): Boolean
    fun restoreFace(inputPath: String, outputPath: String, type: FaceRestoreType): Boolean

    // ============ 信息 ============

    fun getBestBackend(): String
    fun getPerfStats(): String
}
