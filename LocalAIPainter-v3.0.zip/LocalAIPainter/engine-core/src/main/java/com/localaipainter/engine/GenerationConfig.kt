package com.localaipainter.engine

import com.localaipainter.models.LoRAModel
import com.localaipainter.models.ControlNetModel

/**
 * 生成配置 - 所有参数集中管理
 */
data class GenerationConfig(
    val prompt: String = "",
    val negativePrompt: String = "",
    val modelType: ModelType = ModelType.SD15,
    val scheduler: SchedulerType = SchedulerType.EULER_A,
    val steps: Int = 20,
    val cfgScale: Float = 7.5f,
    val seed: Long = -1L,
    val width: Int = 512,
    val height: Int = 512,
    val batchSize: Int = 1,
    val clipSkip: Int = 1,
    val denoisingStrength: Float = 0.7f,
    val loras: List<LoRAModel> = emptyList(),
    val controlNet: ControlNetModel? = null,
    val faceRestore: FaceRestoreType? = null,
    val upscaleFactor: Int = 1,
    val useGpu: Boolean = true,
    val useQuantization: Boolean = true,
    val threads: Int = Runtime.getRuntime().availableProcessors()
) {
    fun isValid(): Boolean {
        if (prompt.isBlank()) return false
        if (width < 64 || height < 64) return false
        if (width % 8 != 0 || height % 8 != 0) return false
        if (steps < 1 || steps > 150) return false
        if (cfgScale < 1f || cfgScale > 30f) return false
        if (batchSize < 1 || batchSize > 8) return false
        return true
    }

    fun effectiveSteps(): Int {
        // LCM 模型推荐更少步数
        return if (modelType == ModelType.LCM) {
            minOf(steps, 8)
        } else {
            steps
        }
    }

    fun resolutionLabel(): String = "${width}x${height}"

    fun toSummary(): String {
        return buildString {
            appendLine("📝 Prompt: ${prompt.take(60)}${if (prompt.length > 60) "..." else ""}")
            appendLine("🎨 Model: ${modelType.displayName}")
            appendLine("⚙️ Scheduler: ${scheduler.displayName}")
            appendLine("📐 Resolution: ${resolutionLabel()}")
            appendLine("🔢 Steps: $steps | CFG: $cfgScale")
            if (loras.isNotEmpty()) {
                appendLine("🔗 LoRA: ${loras.joinToString { it.name }}")
            }
            if (controlNet != null) {
                appendLine("🎮 ControlNet: ${controlNet.type.displayName}")
            }
            if (faceRestore != null) {
                appendLine("👤 Face: ${faceRestore.displayName}")
            }
        }
    }
}
