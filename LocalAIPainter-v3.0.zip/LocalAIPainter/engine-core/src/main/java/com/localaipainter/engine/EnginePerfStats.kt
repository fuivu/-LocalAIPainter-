package com.localaipainter.engine

/**
 * 引擎性能统计
 */
data class EnginePerfStats(
    val avgStepMs: Long = 0,
    val totalTimeS: Double = 0.0,
    val memoryMB: Long = 0,
    val peakMemoryMB: Long = 0,
    val gpuUtilization: Float = 0f,
    val cpuUtilization: Float = 0f,
    val threadsUsed: Int = 0,
    val backend: String = "cpu",
    val modelName: String = "",
    val resolution: String = "",
    val stepsCompleted: Int = 0,
    val tokensPerSecond: Float = 0f
) {
    fun summary(): String = buildString {
        appendLine("⏱ 平均步耗时: ${avgStepMs}ms")
        appendLine("⏳ 总时间: ${String.format("%.1f", totalTimeS)}s")
        appendLine("💾 内存: ${memoryMB}MB (峰值 ${peakMemoryMB}MB)")
        if (backend != "cpu") {
            appendLine("🎮 GPU 利用率: ${String.format("%.0f", gpuUtilization * 100)}%")
        }
        appendLine("🖥 CPU 利用率: ${String.format("%.0f", cpuUtilization * 100)}%")
        appendLine("🔧 线程: $threadsUsed")
        appendLine("⚙️ 后端: $backend")
        appendLine("📐 分辨率: $resolution")
        appendLine("📊 步数: $stepsCompleted")
    }
}
