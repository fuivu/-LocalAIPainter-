package com.localaipainter.engine

/**
 * ControlNet 控制类型
 */
enum class ControlNetType(val value: Int, val displayName: String, val description: String) {
    CANNY(JNIBridge.CONTROL_CANNY, "Canny 边缘", "基于边缘检测控制构图"),
    OPENPOSE(JNIBridge.CONTROL_OPENPOSE, "OpenPose 姿态", "基于人体骨骼姿态控制"),
    DEPTH(JNIBridge.CONTROL_DEPTH, "Depth 深度", "基于深度图控制空间关系"),
    SCRIBBLE(JNIBridge.CONTROL_SCRIBBLE, "Scribble 涂鸦", "基于手绘涂鸦控制"),
    MLSD(JNIBridge.CONTROL_MLSD, "MLSD 线条", "基于建筑线条控制"),
    SEG(JNIBridge.CONTROL_SEG, "Segment 分割", "基于语义分割控制");

    companion object {
        fun fromValue(value: Int): ControlNetType {
            return values().find { it.value == value } ?: CANNY
        }
    }
}
