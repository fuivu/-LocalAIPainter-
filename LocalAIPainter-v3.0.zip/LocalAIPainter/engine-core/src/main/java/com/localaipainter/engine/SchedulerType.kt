package com.localaipainter.engine

/**
 * 采样器（Scheduler）枚举
 */
enum class SchedulerType(val value: Int, val displayName: String, val fastOnly: Boolean = false) {
    EULER_A(JNIBridge.SCHEDULER_EULER_A, "Euler a"),
    EULER(JNIBridge.SCHEDULER_EULER, "Euler"),
    DPM_PP_2M(JNIBridge.SCHEDULER_DPM_PP_2M, "DPM++ 2M"),
    DPM_PP_2M_KARRAS(JNIBridge.SCHEDULER_DPM_PP_2M_KARRAS, "DPM++ 2M Karras"),
    DPM_PP_2S_ANCESTRAL(JNIBridge.SCHEDULER_DPM_PP_2S_ANCESTRAL, "DPM++ 2S Ancestral"),
    LCM(JNIBridge.SCHEDULER_LCM, "LCM", true),
    UNIPC(JNIBridge.SCHEDULER_UNIPC, "UniPC"),
    HEUN(JNIBridge.SCHEDULER_HEUN, "Heun"),
    DDIM(JNIBridge.SCHEDULER_DDIM, "DDIM"),
    PLMS(JNIBridge.SCHEDULER_PLMS, "PLMS");

    companion object {
        fun fromValue(value: Int): SchedulerType {
            return values().find { it.value == value } ?: EULER_A
        }

        fun recommendedForModel(modelType: ModelType): SchedulerType {
            return when (modelType) {
                ModelType.LCM -> LCM
                ModelType.PIXART -> DPM_PP_2M
                ModelType.KOLORS -> DPM_PP_2M_KARRAS
                else -> EULER_A
            }
        }
    }
}
