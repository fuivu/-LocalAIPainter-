package com.localaipainter.engine

/**
 * 模型类型枚举
 */
enum class ModelType(val value: Int, val displayName: String, val sizeMB: Long) {
    SD15(JNIBridge.MODEL_SD15, "Stable Diffusion 1.5", 2048),
    SD21(JNIBridge.MODEL_SD21, "Stable Diffusion 2.1", 5120),
    SDXL(JNIBridge.MODEL_SDXL, "Stable Diffusion XL", 6750),
    LCM(JNIBridge.MODEL_LCM, "LCM (Latent Consistency)", 2048),
    PIXART(JNIBridge.MODEL_PIXART, "PixArt-α", 1200),
    KOLORS(JNIBridge.MODEL_KOLORS, "Kolors (可灵)", 5000);

    companion object {
        fun fromValue(value: Int): ModelType {
            return values().find { it.value == value } ?: SD15
        }
    }
}
