package com.localaipainter.engine

import android.content.Context
import com.localaipainter.models.LoRAModel
import com.localaipainter.models.ControlNetModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow

/**
 * 引擎工厂 - Kotlin 侧
 * 负责创建和管理推理引擎实例，自动选择最佳后端
 */
class EngineFactory(private val context: Context) : InferenceEngine {

    private var _engineId: Int = -1
    private var _isReady = MutableStateFlow(false)
    override val isReady: StateFlow<Boolean> = _isReady

    private val progressAdapter = ProgressAdapter()
    override val progress: StateFlow<Float> = progressAdapter.progress

    private var currentConfig: GenerationConfig? = null
    private var deviceInfo: DeviceInfo? = null

    // ============ 生命周期 ============

    override fun init(context: Context, modelDir: String): Boolean {
        _engineId = JNIBridge.nativeInit(context, modelDir)
        if (_engineId > 0) {
            JNIBridge.nativeSetProgressCallback(progressAdapter)
            deviceInfo = DeviceInfo.detect(context, _engineId)
            _isReady.value = true
            return true
        }
        return false
    }

    override fun loadModel(path: String, type: ModelType): Boolean {
        if (_engineId < 0) return false
        val result = JNIBridge.nativeLoadModel(_engineId, path, type.value)
        if (result) {
            // 自动设置推荐的 scheduler
            val recommended = SchedulerType.recommendedForModel(type)
            setScheduler(recommended)
        }
        return result
    }

    override fun shutdown() {
        if (_engineId > 0) {
            JNIBridge.nativeStop(_engineId)
            JNIBridge.nativeDestroy(_engineId)
            JNIBridge.nativeSetProgressCallback(null)
            _engineId = -1
            _isReady.value = false
        }
    }

    // ============ 配置 ============

    override fun setScheduler(type: SchedulerType) {
        JNIBridge.nativeSetScheduler(_engineId, type.value)
    }

    override fun setSteps(steps: Int) {
        JNIBridge.nativeSetSteps(_engineId, steps)
    }

    override fun setCfgScale(cfg: Float) {
        JNIBridge.nativeSetCfgScale(_engineId, cfg)
    }

    override fun setSeed(seed: Long) {
        JNIBridge.nativeSetSeed(_engineId, seed)
    }

    override fun setResolution(width: Int, height: Int) {
        JNIBridge.nativeSetResolution(_engineId, width, height)
    }

    override fun setClipSkip(skip: Int) {
        JNIBridge.nativeSetClipSkip(_engineId, skip)
    }

    override fun setBatchSize(batch: Int) {
        JNIBridge.nativeSetBatchSize(_engineId, batch)
    }

    override fun setDenoisingStrength(strength: Float) {
        JNIBridge.nativeSetDenoisingStrength(_engineId, strength)
    }

    // ============ 推理 ============

    override suspend fun generate(
        prompt: String,
        negativePrompt: String,
        outputPath: String
    ): Boolean {
        progressAdapter.start(currentConfig?.steps ?: 20)
        return JNIBridge.nativeGenerate(_engineId, prompt, negativePrompt, outputPath)
    }

    override suspend fun generateImageToImage(
        prompt: String,
        negativePrompt: String,
        inputImagePath: String,
        strength: Float,
        outputPath: String
    ): Boolean {
        progressAdapter.start(currentConfig?.steps ?: 20)
        return JNIBridge.nativeGenerateImageToImage(
            _engineId, prompt, negativePrompt, inputImagePath, strength, outputPath
        )
    }

    override fun stop() {
        JNIBridge.nativeStop(_engineId)
        progressAdapter.stop()
    }

    // ============ LoRA ============

    override fun loadLora(path: String, weight: Float): Boolean {
        return JNIBridge.nativeLoadLora(_engineId, path, weight)
    }

    override fun unloadLora(name: String) {
        JNIBridge.nativeUnloadLora(_engineId, name)
    }

    override fun setLoraWeight(name: String, weight: Float) {
        JNIBridge.nativeSetLoraWeight(_engineId, name, weight)
    }

    // ============ ControlNet ============

    override fun loadControlNet(path: String, type: ControlNetType): Boolean {
        return JNIBridge.nativeLoadControlNet(_engineId, path, type.value)
    }

    override fun setControlImage(path: String, strength: Float) {
        JNIBridge.nativeSetControlImage(_engineId, path, strength)
    }

    // ============ 后处理 ============

    override fun upscale(inputPath: String, outputPath: String, scale: Int): Boolean {
        return JNIBridge.nativeUpscale(_engineId, inputPath, outputPath, scale)
    }

    override fun restoreFace(inputPath: String, outputPath: String, type: FaceRestoreType): Boolean {
        return JNIBridge.nativeRestoreFace(_engineId, inputPath, outputPath, type.value)
    }

    // ============ 信息 ============

    override fun getBestBackend(): String {
        return JNIBridge.nativeGetBestBackend(_engineId)
    }

    override fun getPerfStats(): String {
        return JNIBridge.nativeGetPerfStats(_engineId)
    }

    // ============ 便捷方法 ============

    fun generateWithConfig(config: GenerationConfig, outputPath: String): Boolean {
        if (!config.isValid()) return false

        currentConfig = config

        // 应用所有配置
        setSteps(config.effectiveSteps())
        setCfgScale(config.cfgScale)
        setSeed(config.seed)
        setResolution(config.width, config.height)
        setClipSkip(config.clipSkip)
        setBatchSize(config.batchSize)
        setDenoisingStrength(config.denoisingStrength)
        setScheduler(config.scheduler)

        // 加载 LoRA
        for (lora in config.loras) {
            loadLora(lora.path, lora.weight)
        }

        // 设置 ControlNet
        config.controlNet?.let { cn ->
            loadControlNet(cn.path, cn.type)
            setControlImage(cn.imagePath, cn.strength)
        }

        // 执行生成
        val result = JNIBridge.nativeGenerate(
            _engineId, config.prompt, config.negativePrompt, outputPath
        )

        // 后处理：超分
        if (config.upscaleFactor > 1 && result) {
            upscale(outputPath, outputPath, config.upscaleFactor)
        }

        // 后处理：人脸修复
        config.faceRestore?.let { type ->
            if (result) restoreFace(outputPath, outputPath, type)
        }

        return result
    }

    fun getDeviceInfo(): DeviceInfo? = deviceInfo

    fun applyDeviceOptimizations() {
        val device = deviceInfo ?: return
        setResolution(device.recommendedMaxResolution, device.recommendedMaxResolution)
        setSteps(device.recommendedSteps)
    }

    val engineId: Int get() = _engineId
}
