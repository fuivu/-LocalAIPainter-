plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
    id("com.google.devtools.ksp")
}

android {
    namespace = "com.localaipainter"
    compileSdk = rootProject.extra["compileSdk"] as Int

    defaultConfig {
        applicationId = "com.localaipainter"
        minSdk = rootProject.extra["minSdk"] as Int
        targetSdk = rootProject.extra["targetSdk"] as Int
        versionCode = 3
        versionName = "3.0.0"

        // 仅保留 arm64-v8a，砍掉 armeabi-v7a 节省 ~15MB
        ndk {
            abiFilters += listOf("arm64-v8a")
        }

        multiDexEnabled = true

        vectorDrawables {
            useSupportLibrary = true
        }

        // CMake C++ 引擎
        externalNativeBuild {
            cmake {
                cppFlags += "-std=c++17 -O3 -flto"
                arguments += "-DANDROID_STL=c++_shared"
            }
        }

        ndk {
            // Vulkan + OpenCL + NNAPI 支持
            ldLibs += listOf("vulkan", "OpenCL", "neuralnetworks")
        }
    }

    buildTypes {
        debug {
            isMinifyEnabled = false
            isShrinkResources = false
            applicationIdSuffix = ".debug"
        }

        release {
            isMinifyEnabled = true
            isShrinkResources = true
            proguardFiles(
                getDefaultProguardFile("proguard-android-optimize.txt"),
                "proguard-rules.pro"
            )

            androidResources {
                noCompress += listOf("model", "safetensors", "gguf", "onnx", "mnn")
            }
        }
    }

    buildFeatures {
        compose = true
    }

    composeOptions {
        kotlinCompilerExtensionVersion = "2.0.20"
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }

    kotlinOptions {
        jvmTarget = "17"
    }

    packaging {
        resources {
            excludes += listOf(
                "/META-INF/{AL2.0,LGPL2.1}",
                "/META-INF/DEPENDENCIES",
                "/META-INF/LICENSE*",
                "/META-INF/NOTICE*"
            )
        }
        jniLibs {
            useLegacyPackaging = false
        }
    }

    externalNativeBuild {
        cmake {
            path = file("src/main/cpp/CMakeLists.txt")
            version = "3.22.1+"
        }
    }

    flavorDimensions += "backend"
    productFlavors {
        create("full") {
            dimension = "backend"
        }
        create("lite") {
            dimension = "backend"
        }
    }

    sourceSets {
        getByName("main") {
            java.srcDirs(
                "src/main/java",
            )
            res.srcDirs(
                "src/main/res",
            )
            manifest.srcFile("src/main/AndroidManifest.xml")
        }
    }
}

dependencies {
    // Compose BOM
    implementation(platform("androidx.compose:compose-bom:${rootProject.extra["composeBomVersion"]}"))
    implementation("androidx.compose.ui:ui")
    implementation("androidx.compose.ui:ui-graphics")
    implementation("androidx.compose.material3:material3")
    implementation("androidx.compose.material:material-icons-extended")

    // ViewModel & Lifecycle
    implementation("androidx.lifecycle:lifecycle-viewmodel-compose:${rootProject.extra["viewModelVersion"]}")
    implementation("androidx.lifecycle:lifecycle-runtime-compose:${rootProject.extra["viewModelVersion"]}")
    implementation("androidx.lifecycle:lifecycle-service:${rootProject.extra["viewModelVersion"]}")

    // Navigation
    implementation("androidx.navigation:navigation-compose:${rootProject.extra["navigationVersion"]}")

    // DataStore
    implementation("androidx.datastore:datastore-preferences:${rootProject.extra["dataStoreVersion"]}")

    // Room
    implementation("androidx.room:room-runtime:2.6.1")
    implementation("androidx.room:room-ktx:2.6.1")
    ksp("androidx.room:room-compiler:2.6.1")

    // Coroutines
    implementation("org.jetbrains.kotlinx:kotlinx-coroutines-android:${rootProject.extra["coroutinesVersion"]}")

    // Coil 图片加载
    implementation("io.coil-kt:coil-compose:2.7.0")

    // File picker
    implementation("com.github.Airsaid:FilePicker:1.1.0")

    // 权限请求
    implementation("com.guolindev.permissionx:permissionx:1.8.0")

    // WorkManager
    implementation("androidx.work:work-runtime-ktx:2.9.1")

    // SplashScreen
    implementation("androidx.core:core-splashscreen:1.0.1")

    // GPUImage (滤镜)
    implementation("jp.co.cyberagent.android:gpuimage:2.1.0")
}
