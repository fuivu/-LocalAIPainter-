#include "vae_decoder.h"
#include <cmath>
#include <android/log.h>

#define LOGI(...) __android_log_print(ANDROID_LOG_INFO, "VaeDecoder", __VA_ARGS__)

VaeDecoder::VaeDecoder() : loaded_(false), latent_channels_(4), output_channels_(3) {}
VaeDecoder::~VaeDecoder() { release(); }

void VaeDecoder::load(const std::string& path) {
    LOGI("Loading VAE Decoder from: %s", path.c_str());
    loaded_ = true;
}

std::vector<float> VaeDecoder::decode(const std::vector<float>& latents) {
    // VAE decode: 4ch latent → 3ch RGB
    // Latent spatial: 64x64, output: 512x512
    int latent_w = 64, latent_h = 64;
    int out_w = 512, out_h = 512;
    int out_size = out_w * out_h * 3;
    
    std::vector<float> image(out_size);
    
    // Simplified: upsample + scale
    for (int y = 0; y < out_h; y++) {
        for (int x = 0; x < out_w; x++) {
            int ly = (y * latent_h) / out_h;
            int lx = (x * latent_w) / out_w;
            int li = (ly * latent_w + lx) * 4; // 4 latent channels
            
            // Average latent channels → RGB
            float r = latents[li] * 0.5f + 0.5f;
            float g = latents[li + 1] * 0.5f + 0.5f;
            float b = latents[li + 2] * 0.5f + 0.5f;
            
            // Clamp
            r = fmaxf(0, fminf(1, r));
            g = fmaxf(0, fminf(1, g));
            b = fmaxf(0, fminf(1, b));
            
            int oi = (y * out_w + x) * 3;
            image[oi] = r;
            image[oi + 1] = g;
            image[oi + 2] = b;
        }
    }
    
    return image;
}

void VaeDecoder::release() {
    if (loaded_) {
        LOGI("Releasing VAE Decoder");
        loaded_ = false;
    }
}
