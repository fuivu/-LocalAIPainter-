#pragma once
#include <string>
#include <vector>

class VaeDecoder {
public:
    VaeDecoder();
    ~VaeDecoder();
    
    void load(const std::string& path);
    std::vector<float> decode(const std::vector<float>& latents);
    void release();
    
private:
    bool loaded_;
    int latent_channels_;
    int output_channels_;
};
