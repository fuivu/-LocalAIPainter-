#pragma once
#include <vector>
#include <string>

class Unet {
public:
    Unet();
    ~Unet();
    
    void load(const std::string& path);
    void predict(
        const std::vector<float>& latents,
        int timestep,
        const std::vector<float>& cond_emb,
        const std::vector<float>& uncond_emb,
        float cfg_scale,
        std::vector<float>& output
    );
    void release();
    
private:
    bool loaded_;
    // Model weights would be loaded here
    std::vector<float> conv_weights_;
    std::vector<float> norm_weights_;
};
