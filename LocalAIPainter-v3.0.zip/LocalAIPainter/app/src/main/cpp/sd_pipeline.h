#pragma once
#include <string>
#include <vector>
#include "memory_pool.h"

class SDPipeline {
public:
    explicit SDPipeline(MemoryPool* pool);
    ~SDPipeline();
    
    void load(const std::string& model_dir);
    void release();
    
    std::vector<float> generate(
        const std::string& prompt,
        const std::string& negative_prompt,
        int steps,
        float cfg_scale,
        long seed,
        int width,
        int height
    );
    
private:
    MemoryPool* mem_pool_;
    bool loaded_;
    
    // Sub-modules
    void* text_encoder_handle_;
    void* unet_handle_;
    void* vae_handle_;
    
    std::vector<float> encode_text(const std::string& text);
    std::vector<float> denoise_loop(
        std::vector<float>& latents,
        const std::vector<float>& cond_emb,
        const std::vector<float>& uncond_emb,
        int steps, float cfg_scale
    );
    std::vector<float> decode_latents(const std::vector<float>& latents);
};
