package com.localaipainter.util

import android.content.Context
import android.os.Build
import java.io.File

data class ChipInfo(
    val vendor: String,
    val model: String,
    val socName: String,
    val totalRamMB: Long,
    val supportedBackends: List<String>,
    val preferredBackend: String,
    val npuName: String = ""
)

class DeviceDetector(private val context: Context) {

    fun detectChip(): ChipInfo {
        val soc = getSocName()
        val ram = getTotalRam()
        val vendor = identifyVendor(soc)
        val npu = getNpuName(vendor, soc)

        val supported = when (vendor) {
            "Qualcomm" -> listOf("QNN", "MNN", "NCNN", "VULKAN", "ONNX", "CPU")
            "MediaTek" -> listOf("MNN", "NCNN", "VULKAN", "CPU")
            "Samsung"  -> listOf("MNN", "NCNN", "VULKAN", "CPU")
            "Huawei"   -> listOf("MNN", "NCNN", "CPU")
            "Google"   -> listOf("MNN", "NCNN", "VULKAN", "CPU")
            else        -> listOf("MNN", "NCNN", "VULKAN", "CPU")
        }

        val preferred = when (vendor) {
            "Qualcomm" -> if (hasQnnDriver()) "QNN" else "MNN"
            "MediaTek" -> if (hasNeuronDriver()) "NEURON" else "MNN"
            else -> "MNN"
        }

        return ChipInfo(
            vendor = vendor,
            model = soc,
            socName = soc,
            totalRamMB = ram,
            supportedBackends = supported,
            preferredBackend = preferred,
            npuName = npu
        )
    }

    private fun getSocName(): String {
        return when {
            Build.HARDWARE.isNotBlank() -> Build.HARDWARE
            Build.BOARD.isNotBlank() -> Build.BOARD
            else -> "Unknown"
        }
    }

    private fun getTotalRam(): Long {
        val mi = android.app.ActivityManager.MemoryInfo()
        val am = context.getSystemService(Context.ACTIVITY_SERVICE) as android.app.ActivityManager
        am.getMemoryInfo(mi)
        return mi.totalMem / (1024 * 1024)
    }

    private fun identifyVendor(soc: String): String {
        val s = soc.lowercase()
        return when {
            s.contains("qcom") || s.contains("snapdragon") || s.contains("msm") -> "Qualcomm"
            s.contains("mtk") || s.contains("mediatek") || s.contains("dimensity") -> "MediaTek"
            s.contains("exynos") -> "Samsung"
            s.contains("kirin") || s.contains("hi3") -> "Huawei"
            s.contains("tensor") -> "Google"
            else -> "Unknown"
        }
    }

    private fun getNpuName(vendor: String, soc: String): String {
        val s = soc.lowercase()
        return when (vendor) {
            "Qualcomm" -> {
                when {
                    s.contains("8 gen 3") -> "Hexagon NPU (8 Gen 3)"
                    s.contains("8 gen 2") -> "Hexagon NPU (8 Gen 2)"
                    s.contains("8 gen 1") -> "Hexagon NPU (8 Gen 1)"
                    s.contains("7") -> "Hexagon NPU (7 series)"
                    else -> "Hexagon NPU"
                }
            }
            "MediaTek" -> {
                when {
                    s.contains("8400") -> "NPU 880"
                    s.contains("9300") -> "NPU 790"
                    s.contains("9200") -> "NPU 780"
                    s.contains("9000") -> "NPU 590"
                    else -> "APU (MediaTek NPU)"
                }
            }
            "Samsung" -> "Samsung NPU"
            "Huawei" -> "Da Vinci NPU"
            "Google" -> "Edge TPU"
            else -> "Unknown NPU"
        }
    }

    private fun hasQnnDriver(): Boolean {
        val paths = listOf(
            "/vendor/lib64/libQnnHtp.so",
            "/vendor/lib/libQnnHtp.so",
            "/system/lib64/libQnnHtp.so"
        )
        return paths.any { File(it).exists() }
    }

    private fun hasNeuronDriver(): Boolean {
        val paths = listOf(
            "/vendor/lib64/libneuronusdk.so",
            "/vendor/lib/libneuronusdk.so",
            "/system/lib64/libneuronadapter.so"
        )
        return paths.any { File(it).exists() }
    }

    fun isVulkanAvailable(): Boolean {
        val paths = listOf(
            "/vendor/lib64/libvulkan.so",
            "/system/lib64/libvulkan.so"
        )
        return paths.any { File(it).exists() } || Build.VERSION.SDK_INT >= Build.VERSION_CODES.N
    }
}
