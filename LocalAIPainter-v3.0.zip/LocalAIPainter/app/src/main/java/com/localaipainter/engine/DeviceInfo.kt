package com.localaipainter.engine

/**
 * 设备硬件信息 — 用于智能推荐参数
 */
data class DeviceInfo(
    val manufacturer: String = "Unknown",
    val model: String = "Unknown",
    val androidVersion: String = "Unknown",
    val sdkInt: Int = 0,

    // 内存
    val totalRamMB: Long = 0,
    val availableRamMB: Long = 0,

    // CPU
    val cpuCores: Int = 4,
    val cpuMaxFreqMHz: Long = 0,

    // GPU
    val gpuVendor: String = "Unknown",
    val gpuRenderer: String = "Unknown",
    val gpuVersion: String = "Unknown",
    val gpuMemoryMB: Long = 0,
    val supportsVulkan: Boolean = false,
    val supportsOpenCL: Boolean = false,
    val supportsNNAPI: Boolean = false,

    // 存储
    val totalStorageMB: Long = 0,
    val availableStorageMB: Long = 0,

    // 推荐配置
    val recommendedThreads: Int = 4,
    val recommendedSteps: Int = 30,
    val recommendedResolution: String = "512x512",
    val recommendedBatchSize: Int = 1,
    val supportsFP16: Boolean = false,
    val supportsINT8: Boolean = false,
) {
    fun ramGB(): Float = totalRamMB / 1024f

    fun isLowEnd(): Boolean = totalRamMB < 3 * 1024  // < 3GB

    fun isHighEnd(): Boolean = totalRamMB > 8 * 1024 && gpuMemoryMB > 2 * 1024

    fun recommendedPowerMode(): PowerMode = when {
        isLowEnd() -> PowerMode.POWER_SAVE
        isHighEnd() -> PowerMode.HIGH_PERFORMANCE
        else -> PowerMode.BALANCED
    }
}
