package com.localaipainter.data.dao

import androidx.lifecycle.LiveData
import androidx.room.*
import com.localaipainter.data.entity.HistoryEntity

@Dao
interface HistoryDao {
    @Insert suspend fun insert(h: HistoryEntity): Long
    @Query("SELECT * FROM history ORDER BY createdAt DESC") fun getAllLive(): LiveData<List<HistoryEntity>>
    @Query("SELECT * FROM history WHERE id=:id") suspend fun getById(id: Long): HistoryEntity?
    @Query("DELETE FROM history WHERE id=:id") suspend fun deleteById(id: Long)
    @Query("DELETE FROM history") suspend fun clearAll()
}
