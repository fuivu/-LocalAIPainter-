package com.localaipainter.core

import android.content.Context
import com.localaipainter.data.entity.ModelEntity

/**
 * 统一推理引擎接口 - 所有后端（QNN/MNN/NCNN/ONNX/Vulkan/CPU）必须实现此接口
 */
interface InferenceEngine {

    val name: String
    val type: EngineType
    val isAvailable: Boolean

    /**
     * 初始化引擎，加载模型
     */
    suspend fun initialize(model: ModelEntity): Result<Unit>

    /**
     * 执行一次完整推理（TextEncoder → UNet → VAE）
     */
    suspend fun runInference(
        prompt: String,
        negativePrompt: String = "",
        steps: Int,
        cfgScale: Float,
        seed: Long,
        width: Int,
        height: Int,
        loraIds: List<String> = emptyList(),
        onStep: (step: Int, total: Int) -> Unit = { _, _ -> }
    ): Result<FloatArray>  // 返回 RGB float array [0..1]

    /**
     * 释放资源
     */
    fun release()

    /**
     * 获取当前显存/内存占用 (MB)
     */
    fun getMemoryUsageMB(): Long

    /**
     * 支持的量化类型
     */
    fun supportedQuantizations(): List<QuantizationType>
}

enum class EngineType {
    QNN,        // 骁龙 Hexagon NPU
    MNN,        // 阿里 MNN (GPU/CPU)
    NCNN,       // Tencent NCNN (Vulkan)
    ONNX,       // ONNX Runtime
    VULKAN,     // 纯 Vulkan Compute
    CPU         // 纯 CPU 降级
}

enum class QuantizationType {
    NONE,       // FP32
    INT8,       // 8-bit 量化
    INT4        // 4-bit 量化 (极致压缩)
}
