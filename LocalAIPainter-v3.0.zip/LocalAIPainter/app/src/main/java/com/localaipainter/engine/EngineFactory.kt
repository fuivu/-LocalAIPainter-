package com.localaipainter.engine

import android.content.Context
import com.localaipainter.core.BackendProvider
import com.localaipainter.core.PluginRegistry
import com.localaipainter.util.Logger

/**
 * 🏭 引擎工厂 v2.0 —— 委托给 PluginRegistry
 *
 * 工作流程：
 *   1. 按芯片优先级排列候选后端
 *   2. 依次尝试创建（tryCreate）
 *   3. 第一个成功的即返回
 *   4. 全部失败返回 CPU 兜底
 *
 * 新增后端无需修改此类，只需在 PluginRegistry.registerBuiltinBackends() 注册。
 */
object EngineFactory {

    /**
     * 根据芯片信息自动选择最优后端
     */
    fun create(context: Context, chip: com.localaipainter.core.DeviceInfo): InferenceEngine {
        val order = buildList {
            add(chip.preferredBackend)
            addAll(chip.supportedBackends.filter { it != chip.preferredBackend })
            add("CPU") // 永远兜底
        }.distinct()

        Logger.i("EngineFactory", "候选后端顺序: ${order.joinToString()}")

        for (b in order) {
            tryCreate(context, b)?.let { engine ->
                Logger.i("EngineFactory", "✅ 选中后端: $b")
                return engine
            }
        }

        // 最后兜底
        Logger.w("EngineFactory", "⚠️ 所有后端失败，使用 CPU 兜底")
        return CpuEngine(context)
    }

    /**
     * 按后端名创建（不查芯片）
     */
    fun tryCreate(context: Context, backend: String): InferenceEngine? {
        val provider = PluginRegistry.getBackend(backend) ?: run {
            Logger.w("EngineFactory", "未注册的后端: $backend")
            return tryByName(context, backend)
        }
        return try {
            val engine = provider.create(context)
            Logger.d("EngineFactory", "创建成功: ${provider.name} (${provider.description})")
            engine
        } catch (e: Throwable) {
            Logger.w("EngineFactory", "创建失败: $backend -> ${e.message}")
            null
        }
    }

    /**
     * 按名称直接创建（绕过 Registry，用于动态加载）
     */
    fun tryByName(context: Context, name: String): InferenceEngine? = try {
        when (name) {
            "QNN" -> QnnEngine(context)
            "MNN" -> MnnEngine(context)
            "NCNN" -> NcnnEngine(context)
            "VULKAN" -> VulkanEngine(context)
            "ONNX" -> OnnxEngine(context)
            "NEURON" -> NeuronEngine(context)
            else -> CpuEngine(context)
        }
    } catch (e: Throwable) {
        Logger.w("EngineFactory", "tryByName($name) 失败: ${e.message}")
        null
    }

    /**
     * 创建并初始化（一步到位）
     */
    fun createAndInit(context: Context, backend: String): InferenceEngine? {
        return tryCreate(context, backend)?.also { it.init() }
    }

    /**
     * 获取所有已注册后端信息（供 UI 展示）
     */
    fun getAvailableBackends(): List<BackendProvider> =
        PluginRegistry.getAllBackends()

    /**
     * 健康检查：测试所有后端是否可创建
     */
    fun healthCheck(context: Context): Map<String, Boolean> {
        val result = mutableMapOf<String, Boolean>()
        PluginRegistry.getAllBackends().forEach { provider ->
            result[provider.name] = try {
                val eng = provider.create(context)
                eng.init()
                val ok = eng.isInitialized()
                eng.release()
                ok
            } catch (_: Throwable) { false }
        }
        Logger.i("EngineFactory", "健康检查: $result")
        return result
    }
}
