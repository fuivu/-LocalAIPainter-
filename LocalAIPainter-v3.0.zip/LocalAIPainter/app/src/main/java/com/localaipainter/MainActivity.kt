package com.localaipainter

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.viewModels
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.core.view.WindowCompat
import com.localaipainter.data.preferences.UserPreferences
import com.localaipainter.engine.EngineFactory
import com.localaipainter.ui.gallery.GalleryViewModel
import com.localaipainter.ui.generate.GenerateViewModel
import com.localaipainter.ui.models.ModelsViewModel
import com.localaipainter.ui.navigation.AppNavigation
import com.localaipainter.ui.settings.SettingsViewModel
import com.localaipainter.ui.theme.AppTheme
import com.localaipainter.ui.theme.LocalAIPainterTheme

class MainActivity : ComponentActivity() {

    private val engine: EngineFactory by lazy {
        EngineFactory(this).also { ef ->
            ef.init(this, getExternalFilesDir("models")?.absolutePath ?: "")
        }
    }

    private val prefs: UserPreferences by lazy { UserPreferences(this) }

    private val generateViewModel: GenerateViewModel by viewModels {
        object : ViewModelProvider.Factory {
            override fun <T : ViewModel> create(modelClass: Class<T>): T {
                @Suppress("UNCHECKED_CAST")
                return GenerateViewModel(application, engine) as T
            }
        }
    }

    private val galleryViewModel: GalleryViewModel by viewModels()
    private val modelsViewModel: ModelsViewModel by viewModels {
        object : ViewModelProvider.Factory {
            override fun <T : ViewModel> create(modelClass: Class<T>): T {
                @Suppress("UNCHECKED_CAST")
                return ModelsViewModel(application,
                    com.localaipainter.data.ModelRepository(this@MainActivity),
                    engine) as T
            }
        }
    }
    private val settingsViewModel: SettingsViewModel by viewModels {
        object : ViewModelProvider.Factory {
            override fun <T : ViewModel> create(modelClass: Class<T>): T {
                @Suppress("UNCHECKED_CAST")
                return SettingsViewModel(application, prefs, engine) as T
            }
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        WindowCompat.setDecorFitsSystemWindows(window, false)

        // 初始化引擎
        generateViewModel.scanModels()

        setContent {
            val themeName by settingsViewModel.theme.collectAsState(initial = "dark")
            val theme = remember(themeName) {
                when (themeName) {
                    "light" -> AppTheme.LIGHT
                    "amoled" -> AppTheme.AMOLED
                    "sunset" -> AppTheme.SUNSET
                    "deep_sea" -> AppTheme.DEEP_SEA
                    "forest" -> AppTheme.FOREST
                    else -> AppTheme.DARK
                }
            }

            LocalAIPainterTheme(theme = theme) {
                Surface(modifier = Modifier.fillMaxSize()) {
                    AppNavigation(
                        generateViewModel = generateViewModel,
                        galleryViewModel = galleryViewModel,
                        modelsViewModel = modelsViewModel,
                        settingsViewModel = settingsViewModel
                    )
                }
            }
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        engine.shutdown()
    }
}
