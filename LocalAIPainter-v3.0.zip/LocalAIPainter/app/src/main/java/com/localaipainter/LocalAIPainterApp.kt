package com.localaipainter

import android.app.Application
import android.util.Log
import com.localaipainter.core.PluginRegistry
import com.localaipainter.data.preferences.UserPreferences

class LocalAIPainterApp : Application() {

    lateinit var userPreferences: UserPreferences
        private set

    override fun onCreate() {
        super.onCreate()
        instance = this

        userPreferences = UserPreferences(this)

        // 初始化插件系统（后端/调度器/量化/导出/UI模块等）
        PluginRegistry.initAll(this)

        // 初始化日志
        Log.i(TAG, "Local AI Painter v3.0 starting...")

        // 创建必要的目录
        getExternalFilesDir("models")?.mkdirs()
        getExternalFilesDir("models/lora")?.mkdirs()
        getExternalFilesDir("models/controlnet")?.mkdirs()
        getExternalFilesDir("outputs")?.mkdirs()
        getExternalFilesDir("outputs/upscaled")?.mkdirs()
        getExternalFilesDir("logs")?.mkdirs()

        Log.i(TAG, "Directories initialized")
    }

    override fun onTerminate() {
        super.onTerminate()
        PluginRegistry.shutdown()
    }

    companion object {
        private const val TAG = "LocalAIPainter"
        lateinit var instance: LocalAIPainterApp
            private set
    }
}
