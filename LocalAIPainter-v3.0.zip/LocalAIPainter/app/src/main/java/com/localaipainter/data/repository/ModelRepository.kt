package com.localaipainter.data.repository

import com.localaipainter.data.dao.ModelDao
import com.localaipainter.data.entity.ModelEntity

class ModelRepository(private val dao: ModelDao) {
    val allModels = dao.getAllLive()
    fun getByType(t: String) = dao.getByTypeLive(t)
    suspend fun save(m: ModelEntity): Long = dao.insert(m)
    suspend fun update(m: ModelEntity) = dao.update(m)
    suspend fun delete(id: Long) = dao.deleteById(id)
    suspend fun findOne(t: String, b: String): ModelEntity? = dao.findOne(t,b)
}
