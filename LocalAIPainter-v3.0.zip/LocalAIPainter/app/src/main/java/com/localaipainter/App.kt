package com.localaipainter

import android.app.Application
import com.localaipainter.engine.HeterogeneousPipeline
import com.localaipainter.memory.LruTensorCache
import com.localaipainter.util.CrashHandler
import com.localaipainter.util.Logger

/**
 * Application 入口 —— 初始化全局单例
 */
class App : Application() {

    companion object {
        lateinit var instance: App private set
    }

    lateinit var heteroPipeline: HeterogeneousPipeline
        private set
    lateinit var tensorCache: LruTensorCache
        private set

    override fun onCreate() {
        super.onCreate()
        instance = this

        Logger.init(this)
        CrashHandler.init(this)

        Logger.i("=== Local AI Painter v2.0 starting ===")

        tensorCache = LruTensorCache(maxSizeMB = 1024)
        heteroPipeline = HeterogeneousPipeline(this, tensorCache)
        heteroPipeline.init()

        Logger.i("App init complete")
    }

    override fun onTerminate() {
        heteroPipeline.release()
        tensorCache.clear()
        Logger.i("App terminated, resources released")
        super.onTerminate()
    }
}
