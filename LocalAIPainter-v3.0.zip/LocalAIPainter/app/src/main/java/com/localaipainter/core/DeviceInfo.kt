package com.localaipainter.core

import com.localaipainter.engine.DeviceInfo as EngineDeviceInfo

/**
 * 设备信息 — 核心层引用
 *
 * 直接 typealias 到 engine 模块的 DeviceInfo，
 * 避免两套定义导致的不一致。
 */
typealias DeviceInfo = EngineDeviceInfo
