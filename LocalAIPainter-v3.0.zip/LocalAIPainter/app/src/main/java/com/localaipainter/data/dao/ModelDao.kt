package com.localaipainter.data.dao

import androidx.lifecycle.LiveData
import androidx.room.*
import com.localaipainter.data.entity.ModelEntity

@Dao
interface ModelDao {
    @Insert suspend fun insert(m: ModelEntity): Long
    @Update suspend fun update(m: ModelEntity)
    @Delete suspend fun delete(m: ModelEntity)
    @Query("SELECT * FROM models ORDER BY importedAt DESC") fun getAllLive(): LiveData<List<ModelEntity>>
    @Query("SELECT * FROM models WHERE type=:t ORDER BY importedAt DESC") fun getByTypeLive(t: String): LiveData<List<ModelEntity>>
    @Query("SELECT * FROM models WHERE id=:id") suspend fun getById(id: Long): ModelEntity?
    @Query("SELECT * FROM models WHERE type=:t AND backend=:b LIMIT 1") suspend fun findOne(t: String, b: String): ModelEntity?
    @Query("DELETE FROM models WHERE id=:id") suspend fun deleteById(id: Long)
}
