package com.localaipainter.data.db.dao

import androidx.lifecycle.LiveData
import androidx.room.*
import com.localaipainter.data.db.GenerationHistory

/**
 * 生成历史 DAO
 */
@Dao
interface GenerationHistoryDao {

    @Insert
    suspend fun insert(history: GenerationHistory): Long

    @Update
    suspend fun update(history: GenerationHistory)

    @Delete
    suspend fun delete(history: GenerationHistory)

    @Query("DELETE FROM generation_history WHERE id = :id")
    suspend fun deleteById(id: Long)

    @Query("DELETE FROM generation_history")
    suspend fun clearAll()

    @Query("SELECT * FROM generation_history ORDER BY timestamp DESC")
    fun getAll(): LiveData<List<GenerationHistory>>

    @Query("SELECT * FROM generation_history WHERE isFavorite = 1 ORDER BY timestamp DESC")
    fun getFavorites(): LiveData<List<GenerationHistory>>

    @Query("SELECT * FROM generation_history WHERE timestamp >= :since ORDER BY timestamp DESC LIMIT :limit")
    fun getRecent(since: Long, limit: Int = 50): LiveData<List<GenerationHistory>>

    @Query("SELECT * FROM generation_history WHERE id = :id")
    suspend fun getById(id: Long): GenerationHistory?

    @Query("UPDATE generation_history SET isFavorite = :fav WHERE id = :id")
    suspend fun setFavorite(id: Long, fav: Boolean)

    @Query("UPDATE generation_history SET userRating = :rating WHERE id = :id")
    suspend fun setRating(id: Long, rating: Int)

    @Query("UPDATE generation_history SET userNote = :note WHERE id = :id")
    suspend fun setNote(id: Long, note: String)

    @Query("SELECT COUNT(*) FROM generation_history")
    fun getCount(): LiveData<Int>

    @Query("SELECT AVG(generationTimeMs) FROM generation_history WHERE generationTimeMs > 0")
    fun getAvgGenTime(): LiveData<Double>
}
