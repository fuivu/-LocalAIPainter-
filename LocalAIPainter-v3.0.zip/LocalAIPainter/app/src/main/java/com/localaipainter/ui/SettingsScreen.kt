package com.localaipainter.ui.settings

import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.localaipainter.App
import com.localaipainter.core.MemoryManager

@Composable
fun SettingsScreen(app: App) {
    val memoryManager = app.memoryManager
    var strategy by remember { mutableStateOf(memoryManager.getStrategy()) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFF0F0F1A))
            .verticalScroll(rememberScrollState())
            .padding(16.dp)
    ) {
        Text("设置", fontSize = 24.sp, fontWeight = FontWeight.Bold, color = Color.White)
        Spacer(Modifier.height(24.dp))

        // 内存管理
        Text("内存管理", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 16.sp)
        Spacer(Modifier.height(8.dp))

        val strategies = MemoryManager.Strategy.values()
        strategies.forEach { s ->
            val selected = strategy == s
            Card(
                modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp).clickable {
                    strategy = s
                    memoryManager.setStrategy(s)
                },
                colors = CardDefaults.cardColors(
                    containerColor = if (selected) Color(0xFF7C4DFF) else Color(0xFF1A1A2E)
                ),
                shape = RoundedCornerShape(8.dp)
            ) {
                Column(Modifier.padding(16.dp)) {
                    Text(
                        when (s) {
                            MemoryManager.Strategy.BALANCED -> "均衡模式 (推荐)"
                            MemoryManager.Strategy.CONSERVATIVE -> "保守模式"
                            MemoryManager.Strategy.AGGRESSIVE -> "极限压缩"
                            MemoryManager.Strategy.MINIMAL -> "最低配置"
                        },
                        color = Color.White,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        when (s) {
                            MemoryManager.Strategy.BALANCED -> "全精度 + 张量缓存，适合 8GB+ 设备"
                            MemoryManager.Strategy.CONSERVATIVE -> "INT8 量化 + 限制并发，适合 4-6GB"
                            MemoryManager.Strategy.AGGRESSIVE -> "INT4 量化 + 最小缓存，适合 2-3GB"
                            MemoryManager.Strategy.MINIMAL -> "CPU only + 超低分辨率，适合 2GB 以下"
                        },
                        color = Color.LightGray,
                        fontSize = 11.sp
                    )
                }
            }
        }

        Spacer(Modifier.height(24.dp))

        // 引擎信息
        Text("推理引擎", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 16.sp)
        Spacer(Modifier.height(8.dp))

        val engines = app.engineFactory.getAllEngines()
        engines.forEach { engine ->
            Card(
                modifier = Modifier.fillMaxWidth().padding(vertical = 2.dp),
                colors = CardDefaults.cardColors(containerColor = Color(0xFF1A1A2E)),
                shape = RoundedCornerShape(8.dp)
            ) {
                Row(Modifier.padding(12.dp)) {
                    Text(engine.name, color = Color.White, modifier = Modifier.weight(1f))
                    Text(
                        if (engine.isAvailable) "✓ 可用" else "✗ 不可用",
                        color = if (engine.isAvailable) Color(0xFF4CAF50) else Color.Gray,
                        fontSize = 12.sp
                    )
                }
            }
        }

        Spacer(Modifier.height(24.dp))

        // 其他设置
        Card(
            modifier = Modifier.fillMaxWidth(),
            colors = CardDefaults.cardColors(containerColor = Color(0xFF1A1A2E)),
            shape = RoundedCornerShape(8.dp)
        ) {
            Column(Modifier.padding(16.dp)) {
                var bootStart by remember { mutableStateOf(true) }
                Row(Modifier.fillMaxWidth()) {
                    Text("开机自动恢复服务", color = Color.White, modifier = Modifier.weight(1f))
                    Switch(checked = bootStart, onCheckedChange = { bootStart = it })
                }
                Divider(color = Color(0xFF303048))
                var autoDegrade by remember { mutableStateOf(true) }
                Row(Modifier.fillMaxWidth()) {
                    Text("低内存时自动降级", color = Color.White, modifier = Modifier.weight(1f))
                    Switch(checked = autoDegrade, onCheckedChange = { autoDegrade = it })
                }
            }
        }

        Spacer(Modifier.height(16.dp))

        // 清除缓存
        OutlinedButton(
            onClick = { /* clear cache */ },
            modifier = Modifier.fillMaxWidth(),
            colors = ButtonDefaults.outlinedButtonColors(contentColor = Color(0xFFF44336))
        ) {
            Text("清除缓存")
        }

        Spacer(Modifier.height(8.dp))

        // 内存报告
        Text(memoryManager.getMemoryReport(), color = Color.DarkGray, fontSize = 10.sp)
    }
}
