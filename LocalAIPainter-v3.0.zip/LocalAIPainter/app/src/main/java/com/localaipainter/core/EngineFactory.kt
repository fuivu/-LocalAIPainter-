package com.localaipainter.core

import android.content.Context

/**
 * 引擎工厂 (JNI 桥接) —— 提供底层 C++ 引擎查询能力
 */
object EngineFactory {

    fun tryCreate(context: Context, backend: String): com.localaipainter.engine.InferenceEngine? {
        // 委托给 engine 包的 EngineFactory
        return com.localaipainter.engine.EngineFactory.tryCreate(context, backend)
    }

    /** 返回底层支持的推理后端列表（由 C++ 侧实现） */
    external fun nativeGetSupportedBackends(): String

    fun getSupportedBackends(): List<String> {
        return try {
            nativeGetSupportedBackends().split(",").map { it.trim() }
        } catch (e: UnsatisfiedLinkError) {
            listOf("CPU")
        }
    }

    init {
        try {
            System.loadLibrary("engine_factory")
        } catch (e: UnsatisfiedLinkError) {
            // 桩模式下忽略
        }
    }
}
