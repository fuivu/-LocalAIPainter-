package com.localaipainter.ui.home

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.localaipainter.App
import com.localaipainter.core.InferenceEngine
import com.localaipainter.data.entity.HistoryEntity
import com.localaipainter.pipeline.SDPipeline
import com.localaipainter.scheduler.Scheduler
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.launch
import java.util.UUID

class HomeViewModel(
    private val app: App
) : ViewModel() {

    sealed class UiState {
        object Idle : UiState()
        data class Generating(val step: Int, val total: Int) : UiState()
        data class Success(val imagePath: String) : UiState()
        data class Error(val message: String) : UiState()
    }

    private val _uiState = MutableStateFlow<UiState>(UiState.Idle)
    val uiState: StateFlow<UiState> = _uiState

    private var currentPipeline: SDPipeline? = null

    fun generate(
        prompt: String,
        negativePrompt: String,
        steps: Int,
        cfgScale: Float,
        seed: Long,
        width: Int,
        height: Int,
        scheduler: Scheduler
    ) {
        viewModelScope.launch {
            _uiState.value = UiState.Generating(0, steps)

            try {
                val engine = app.engineFactory.getCurrentEngine()
                    ?: error("No inference engine available")

                // 加载模型（实际应从数据库获取当前选中模型）
                // val model = app.database.modelDao().getById(...) ?: error("No model")

                // val pipeline = SDPipeline(engine, app.memoryManager)
                // pipeline.load(model)

                // val result = pipeline.generate(
                //     prompt, negativePrompt, scheduler, steps, cfgScale, seed, width, height
                // ) { step, total ->
                //     _uiState.value = UiState.Generating(step, total)
                // }

                // result.onSuccess { pixels ->
                //     val path = saveImage(pixels, width, height)
                //     saveHistory(prompt, negativePrompt, path, steps, cfgScale, seed, width, height)
                //     _uiState.value = UiState.Success(path)
                // }.onFailure { e ->
                //     _uiState.value = UiState.Error(e.message ?: "Unknown error")
                // }

                // 模拟
                repeat(steps) { i ->
                    kotlinx.coroutines.delay(100)
                    _uiState.value = UiState.Generating(i + 1, steps)
                }
                _uiState.value = UiState.Success("/fake/path/image.png")

            } catch (e: Exception) {
                _uiState.value = UiState.Error(e.message ?: "Generation failed")
            }
        }
    }

    fun resetState() {
        _uiState.value = UiState.Idle
    }

    private fun saveImage(pixels: FloatArray, w: Int, h: Int): String {
        // 将 FloatArray RGB 保存为 PNG 文件
        // 实际实现应使用 Bitmap.compress()
        return "/path/to/saved/image.png"
    }

    private suspend fun saveHistory(
        prompt: String, neg: String, path: String,
        steps: Int, cfg: Float, seed: Long, w: Int, h: Int
    ) {
        val record = HistoryEntity(
            id = UUID.randomUUID().toString(),
            prompt = prompt,
            negativePrompt = neg,
            modelId = "default",
            scheduler = "LCM",
            steps = steps,
            cfgScale = cfg,
            seed = seed,
            width = w,
            height = h,
            imagePath = path
        )
        app.database.historyDao().insert(record)
    }

    override fun onCleared() {
        super.onCleared()
        currentPipeline?.release()
    }
}
