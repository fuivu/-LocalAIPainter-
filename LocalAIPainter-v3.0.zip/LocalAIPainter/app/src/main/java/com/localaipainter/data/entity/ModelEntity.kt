package com.localaipainter.data.entity

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "models")
data class ModelEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val name: String,
    val filePath: String,
    val type: String,
    val backend: String,
    val precision: String,
    val fileSize: Long,
    val verified: Boolean = false,
    val importedAt: Long = System.currentTimeMillis()
)
