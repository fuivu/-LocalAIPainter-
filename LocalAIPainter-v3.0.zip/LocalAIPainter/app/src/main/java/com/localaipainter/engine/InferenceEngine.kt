package com.localaipainter.engine

import android.content.Context

/**
 * 推理引擎抽象接口 —— 统一 MNN / NCNN / Vulkan / CPU 四种后端
 */
interface InferenceEngine {
    val backendName: String
    fun loadModel(modelPath: String): Boolean
    fun unloadModel()
    fun runInference(input: FloatArray, width: Int, height: Int): FloatArray
    fun isAvailable(): Boolean
    fun getMemoryUsageMB(): Int
    fun release()
}

/**
 * 引擎工厂 —— 按后端名称创建对应实例
 */
object EngineFactory {
    private const val TAG = "EngineFactory"

    fun tryCreate(context: Context, backend: String): InferenceEngine? = when (backend.uppercase()) {
        "MNN" -> MnnEngine(context)
        "NCNN" -> NcnnEngine(context)
        "VULKAN" -> VulkanEngine(context)
        "CPU" -> CpuEngine(context)
        else -> {
            Logger.w("Unknown backend: $backend, fallback to CPU")
            CpuEngine(context)
        }
    }

    fun getSupportedBackends(): Array<String> = arrayOf("MNN", "NCNN", "VULKAN", "CPU")

    fun getBestBackend(): String {
        // TODO: 实际检测 NPU/GPU 可用性后返回最优
        return "MNN"
    }
}
