package com.localaipainter.data.entity

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "gen_configs")
data class GenerationConfig(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val name: String,
    val prompt: String,
    val negativePrompt: String = "",
    val steps: Int = 20,
    val cfgScale: Float = 7.5f,
    val width: Int = 512,
    val height: Int = 512,
    val seed: Long = -1,
    val scheduler: String = "EulerA",
    val initImagePath: String? = null,
    val maskImagePath: String? = null,
    val denoisingStrength: Float = 0.75f,
    val clipSkip: Int = 2,
    val batchCount: Int = 1,
    val batchSize: Int = 1,
    val loraIds: String = "",
    val loraScales: String = "",
    val createdAt: Long = System.currentTimeMillis()
)
