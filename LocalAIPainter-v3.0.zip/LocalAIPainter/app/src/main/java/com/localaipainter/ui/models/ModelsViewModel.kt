package com.localaipainter.ui.models

import android.app.Application
import androidx.lifecycle.*
import com.localaipainter.data.ModelRepository
import com.localaipainter.engine.EngineFactory
import com.localaipainter.engine.ModelType
import com.localaipainter.models.ControlNetModel
import com.localaipainter.models.LoRAModel
import com.localaipainter.models.ModelInfo
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch

class ModelsViewModel(
    application: Application,
    private val repo: ModelRepository,
    private val engine: EngineFactory
) : AndroidViewModel(application) {

    enum class ModelCategory { CHECKPOINT, LORA, CONTROLNET, VAE, EMBEDDING }

    private val _category = MutableStateFlow(ModelCategory.CHECKPOINT)
    val category: StateFlow<ModelCategory> = _category

    private val _importStatus = MutableStateFlow<String?>(null)
    val importStatus: StateFlow<String?> = _importStatus

    val checkpoints: StateFlow<List<ModelInfo>> = repo.models
    val loras: StateFlow<List<LoRAModel>> = repo.loras
    val controlNets: StateFlow<List<ControlNetModel>> = repo.controlNets

    val displayedModels: StateFlow<List<Any>> =
        combine(_category, repo.models, repo.loras, repo.controlNets) { cat, models, loras, cns ->
            when (cat) {
                ModelCategory.CHECKPOINT -> models
                ModelCategory.LORA -> loras
                ModelCategory.CONTROLNET -> cns
                ModelCategory.VAE -> emptyList() // TODO
                ModelCategory.EMBEDDING -> emptyList() // TODO
            }
        }.stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())

    // ============ Actions ============

    fun setCategory(cat: ModelCategory) { _category.value = cat }

    fun scanAll() {
        repo.scanModels()
        repo.scanLoras()
        repo.scanControlNets()
    }

    fun importModel(sourcePath: String) {
        viewModelScope.launch {
            val success = repo.importModel(sourcePath)
            _importStatus.value = if (success) "导入成功" else "导入失败"
            scanAll()
        }
    }

    fun deleteModel(name: String) {
        repo.deleteModel(name)
    }

    fun loadModelAsActive(path: String, type: ModelType): Boolean {
        return engine.loadModel(path, type)
    }

    fun clearImportStatus() { _importStatus.value = null }
}
