package com.localaipainter.data.db

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.room.TypeConverters
import com.localaipainter.data.db.dao.GenerationHistoryDao

/**
 * Room 数据库 — 主入口
 */
@Database(
    entities = [GenerationHistory::class],
    version = 3,
    exportSchema = false,
)
@TypeConverters(Converters::class)
abstract class AppDatabase : RoomDatabase() {

    abstract fun generationHistoryDao(): GenerationHistoryDao

    companion object {
        @Volatile private var INSTANCE: AppDatabase? = null

        fun getInstance(context: Context): AppDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    AppDatabase::class.java,
                    "local_ai_painter.db",
                )
                    .fallbackToDestructiveMigration()
                    .build()
                INSTANCE = instance
                instance
            }
        }
    }
}

/**
 * Room TypeConverters
 */
class Converters {
    @androidx.room.TypeConverter
    fun fromStringList(value: List<String>): String =
        value.joinToString("||")

    @androidx.room.TypeConverter
    fun toStringList(value: String): List<String> =
        if (value.isEmpty()) emptyList() else value.split("||")

    @androidx.room.TypeConverter
    fun fromLong(value: Long): Long = value

    @androidx.room.TypeConverter
    fun toLong(value: Long): Long = value
}
