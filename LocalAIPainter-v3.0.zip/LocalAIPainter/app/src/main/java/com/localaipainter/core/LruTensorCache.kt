package com.localaipainter.core

import java.util.LinkedHashMap

/**
 * LRU 张量缓存 - 自动淘汰最久未使用的张量
 */
class LruTensorCache(private var maxSizeMB: Int) {

    private val cache = object : LinkedHashMap<String, CachedTensor>(16, 0.75f, true) {
        override fun removeEldestEntry(eldest: MutableMap.MutableEntry<String, CachedTensor>): Boolean {
            val total = cache.values.sumOf { it.sizeMB.toLong() }
            if (total > maxSizeMB) {
                eldest.value.release()
                return true
            }
            return false
        }
    }

    fun put(key: String, tensor: CachedTensor) {
        cache[key]?.release()
        cache[key] = tensor
    }

    fun get(key: String): CachedTensor? = cache[key]

    fun remove(key: String) {
        cache[key]?.release()
        cache.remove(key)
    }

    fun clear() {
        cache.values.forEach { it.release() }
        cache.clear()
    }

    fun sizeMB(): Int = cache.values.sumOf { it.sizeMB.toLong() }.toInt()

    fun resize(newMaxMB: Int) {
        maxSizeMB = newMaxMB
        // 触发淘汰
        while (sizeMB() > maxSizeMB && cache.isNotEmpty()) {
            val eldest = cache.entries.first()
            eldest.value.release()
            cache.remove(eldest.key)
        }
    }

    fun stats(): String {
        return "Cache: ${cache.size} tensors, ${sizeMB()}MB / ${maxSizeMB}MB"
    }
}

class CachedTensor(
    val key: String,
    val sizeMB: Int,
    private val onRelease: () -> Unit
) {
    fun release() {
        onRelease()
    }
}
