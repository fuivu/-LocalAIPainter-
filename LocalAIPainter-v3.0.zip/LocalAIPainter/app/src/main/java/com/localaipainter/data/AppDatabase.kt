package com.localaipainter.data

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import com.localaipainter.data.dao.HistoryDao
import com.localaipainter.data.dao.ModelDao
import com.localaipainter.data.dao.TaskDao
import com.localaipainter.data.entity.HistoryEntity
import com.localaipainter.data.entity.ModelEntity
import com.localaipainter.data.entity.TaskEntity

@Database(
    entities = [ModelEntity::class, HistoryEntity::class, TaskEntity::class],
    version = 1,
    exportSchema = false
)
abstract class AppDatabase : RoomDatabase() {

    abstract fun modelDao(): ModelDao
    abstract fun historyDao(): HistoryDao
    abstract fun taskDao(): TaskDao

    companion object {
        @Volatile
        private var INSTANCE: AppDatabase? = null

        fun getInstance(context: Context): AppDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    AppDatabase::class.java,
                    "localaipainter.db"
                )
                    .fallbackToDestructiveMigration()
                    .build()
                INSTANCE = instance
                instance
            }
        }
    }
}
