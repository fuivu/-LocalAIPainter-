package com.localaipainter.data.dao

import androidx.lifecycle.LiveData
import androidx.room.*
import com.localaipainter.data.entity.GenerationConfig

@Dao
interface GenerationConfigDao {
    @Insert suspend fun insert(c: GenerationConfig): Long
    @Update suspend fun update(c: GenerationConfig)
    @Delete suspend fun delete(c: GenerationConfig)
    @Query("SELECT * FROM gen_configs ORDER BY createdAt DESC") fun getAllLive(): LiveData<List<GenerationConfig>>
    @Query("SELECT * FROM gen_configs WHERE id=:id") suspend fun getById(id: Long): GenerationConfig?
}
