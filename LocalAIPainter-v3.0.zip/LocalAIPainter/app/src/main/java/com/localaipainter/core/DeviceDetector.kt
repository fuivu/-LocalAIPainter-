package com.localaipainter.core

import android.content.Context
import android.os.Build
import android.os.Debug

/**
 * 🔍 设备检测器 v2.0 —— 精准识别芯片 + NPU/GPU 能力
 *
 * 覆盖：天玑 7000/8000/9000/10000 系列、骁龙 6/7/8 Gen 系列、
 *       Exynos、麒麟、Tensor、Google G 系列
 * 扩展：新增芯片只需在 CHIP_DATABASE 中加一条记录
 */
class DeviceDetector(private val context: Context) {

    companion object {
        // ---- 芯片数据库（新增芯片在此加一行）----
        private val CHIP_DATABASE: List<ChipProfile> = listOf(
            // === 联发科 天玑 ===
            ChipProfile("dimensity 10000", "天玑 10000", "MediaTek", "NPU 880+", 12000, listOf("NEURON", "MNN", "NCNN", "VULKAN", "CPU"), "NEURON"),
            ChipProfile("dimensity 9400", "天玑 9400", "MediaTek", "NPU 880", 12000, listOf("NEURON", "MNN", "NCNN", "VULKAN", "CPU"), "NEURON"),
            ChipProfile("dimensity 9300", "天玑 9300", "MediaTek", "NPU 790", 12000, listOf("NEURON", "MNN", "NCNN", "VULKAN", "CPU"), "NEURON"),
            ChipProfile("dimensity 9200", "天玑 9200", "MediaTek", "NPU 790", 12000, listOf("NEURON", "MNN", "VULKAN", "CPU"), "NEURON"),
            ChipProfile("dimensity 9000", "天玑 9000", "MediaTek", "APU 590", 8000, listOf("MNN", "VULKAN", "NCNN", "CPU"), "MNN"),
            ChipProfile("dimensity 8400", "天玑 8400", "MediaTek", "NPU 880", 8000, listOf("NEURON", "MNN", "VULKAN", "NCNN", "CPU"), "NEURON"),
            ChipProfile("dimensity 8300", "天玑 8300", "MediaTek", "APU 780", 8000, listOf("MNN", "VULKAN", "NCNN", "CPU"), "MNN"),
            ChipProfile("dimensity 8200", "天玑 8200", "MediaTek", "APU 580", 8000, listOf("MNN", "VULKAN", "NCNN", "CPU"), "MNN"),
            ChipProfile("dimensity 8000", "天玑 8000", "MediaTek", "APU 580", 6000, listOf("MNN", "VULKAN", "NCNN", "CPU"), "MNN"),
            ChipProfile("dimensity 7000", "天玑 7000", "MediaTek", "APU 550", 6000, listOf("MNN", "VULKAN", "NCNN", "CPU"), "MNN"),

            // === 高通 骁龙 ===
            ChipProfile("snapdragon 8 gen 3", "骁龙 8 Gen 3", "Qualcomm", "Hexagon NPU", 12000, listOf("QNN", "MNN", "VULKAN", "CPU"), "QNN"),
            ChipProfile("sm8650", "骁龙 8 Gen 3", "Qualcomm", "Hexagon NPU", 12000, listOf("QNN", "MNN", "VULKAN", "CPU"), "QNN"),
            ChipProfile("snapdragon 8 gen 2", "骁龙 8 Gen 2", "Qualcomm", "Hexagon NPU", 12000, listOf("QNN", "MNN", "VULKAN", "CPU"), "QNN"),
            ChipProfile("sm8550", "骁龙 8 Gen 2", "Qualcomm", "Hexagon NPU", 12000, listOf("QNN", "MNN", "VULKAN", "CPU"), "QNN"),
            ChipProfile("snapdragon 8 gen 1", "骁龙 8 Gen 1", "Qualcomm", "Hexagon NPU", 8000, listOf("QNN", "MNN", "VULKAN", "CPU"), "QNN"),
            ChipProfile("snapdragon 7 gen 3", "骁龙 7 Gen 3", "Qualcomm", "Hexagon NPU", 8000, listOf("QNN", "MNN", "VULKAN", "CPU"), "QNN"),
            ChipProfile("snapdragon 7s gen 2", "骁龙 7s Gen 2", "Qualcomm", "Hexagon NPU", 8000, listOf("MNN", "VULKAN", "CPU"), "MNN"),

            // === 三星 Exynos ===
            ChipProfile("exynos 2400", "Exynos 2400", "Samsung", "NPU 330", 12000, listOf("MNN", "VULKAN", "NCNN", "CPU"), "MNN"),
            ChipProfile("exynos 2200", "Exynos 2200", "Samsung", "NPU 280", 8000, listOf("MNN", "VULKAN", "NCNN", "CPU"), "MNN"),

            // === 华为 麒麟 ===
            ChipProfile("kirin 9000", "麒麟 9000", "Huawei", "Da Vinci NPU", 12000, listOf("MNN", "NCNN", "CPU"), "MNN"),
            ChipProfile("hi3660", "麒麟 960", "Huawei", "i7 NPU", 4000, listOf("MNN", "NCNN", "CPU"), "MNN"),

            // === Google Tensor ===
            ChipProfile("tensor g3", "Tensor G3", "Google", "Edge TPU", 12000, listOf("MNN", "VULKAN", "CPU"), "MNN"),
            ChipProfile("tensor g2", "Tensor G2", "Google", "Edge TPU", 8000, listOf("MNN", "VULKAN", "CPU"), "MNN"),
        )
    }

    fun detect(): DeviceInfo {
        val totalRamMB = getTotalRamMB()
        val chipset = detectChipset()
        val profile = matchChipProfile(chipset)
        val npuType = profile?.let { mapNpuType(it.npuName) } ?: NpuType.NONE
        val hasVulkan = checkVulkanSupport()
        val cpuCores = Runtime.getRuntime().availableProcessors()
        val gpuName = detectGpuName()

        val supportedBackends = profile?.supportedBackends ?: listOf("MNN", "NCNN", "VULKAN", "CPU")
        val preferred = profile?.preferredBackend ?: if (hasVulkan) "MNN" else "NCNN"

        return DeviceInfo(
            chipset = chipset,
            chipName = profile?.displayName ?: chipset,
            vendor = profile?.vendor ?: "Unknown",
            npuName = profile?.npuName ?: "None",
            npuType = npuType,
            gpuName = gpuName,
            totalRamMB = totalRamMB,
            hasVulkan = hasVulkan,
            cpuCores = cpuCores,
            androidVersion = Build.VERSION.SDK_INT,
            androidRelease = Build.VERSION.RELEASE,
            supportedBackends = supportedBackends,
            preferredBackend = preferred,
            isLowEnd = totalRamMB < 4096,
            isHighEnd = totalRamMB >= 12000,
            abi = Build.SUPPORTED_ABIS?.firstOrNull() ?: "armeabi-v7a"
        )
    }

    private fun matchChipProfile(chipset: String): ChipProfile? {
        val lower = chipset.lowercase()
        return CHIP_DATABASE.firstOrNull { lower.contains(it.keyword) }
    }

    private fun mapNpuType(npuName: String): NpuType {
        val n = npuName.lowercase()
        return when {
            n.contains("hexagon") -> NpuType.HEXAGON
            n.contains("npu 880") || n.contains("npu 790") -> NpuType.MEDIATEK_APU
            n.contains("apu") -> NpuType.MEDIATEK_APU
            n.contains("da vinci") || n.contains("kirin") -> NpuType.KIRIN_NPU
            n.contains("edge tpu") -> NpuType.GOOGLE_TPU
            n.contains("npu") -> NpuType.GENERIC_NPU
            else -> NpuType.NONE
        }
    }

    private fun detectChipset(): String {
        return Build.SOC_MODEL?.ifBlank { null }
            ?: Build.HARDWARE?.ifBlank { null }
            ?: Build.BOARD?.ifBlank { null }
            ?: "unknown"
    }

    private fun detectGpuName(): String {
        // 通过 Vulkan 扩展探测（简化版）
        return when {
            Build.HARDWARE?.lowercase()?.contains("mt6") == true -> "Mali-G57"
            Build.HARDWARE?.lowercase()?.contains("mt8") == true -> "Mali-G720"
            Build.HARDWARE?.lowercase()?.contains("mt9") == true -> "Mali-G925"
            else -> "Unknown GPU"
        }
    }

    private fun getTotalRamMB(): Long {
        return try {
            val am = context.getSystemService(Context.ACTIVITY_SERVICE) as android.app.ActivityManager
            val mi = android.app.ActivityManager.MemoryInfo()
            am.getMemoryInfo(mi)
            mi.totalMem / (1024 * 1024)
        } catch (_: Throwable) { 4096L }
    }

    private fun checkVulkanSupport(): Boolean {
        return try {
            val pm = context.packageManager
            pm.hasSystemFeature("android.hardware.vulkan.level") ||
            pm.hasSystemFeature("android.hardware.vulkan.version")
        } catch (_: Throwable) { false }
    }

    // ---- 数据类 ----

    private data class ChipProfile(
        val keyword: String,          // 用于匹配 Build.SOC_MODEL 等
        val displayName: String,
        val vendor: String,
        val npuName: String,
        val typicalRamMB: Long,
        val supportedBackends: List<String>,
        val preferredBackend: String
    )
}

// ---- 对外暴露的数据类 ----

data class DeviceInfo(
    val chipset: String,
    val chipName: String,
    val vendor: String,
    val npuName: String,
    val npuType: NpuType,
    val gpuName: String,
    val totalRamMB: Long,
    val hasVulkan: Boolean,
    val cpuCores: Int,
    val androidVersion: Int,
    val androidRelease: String,
    val supportedBackends: List<String>,
    val preferredBackend: String,
    val isLowEnd: Boolean,
    val isHighEnd: Boolean,
    val abi: String
) {
    fun supports(backend: String): Boolean = supportedBackends.contains(backend)
    fun summary(): String = "$chipName | $npuName | RAM ${totalRamMB}MB | Vulkan=$hasVulkan"
}

enum class NpuType {
    HEXAGON, MEDIATEK_APU, KIRIN_NPU, EXYNOS_NPU, GOOGLE_TPU, GENERIC_NPU, NONE
}
