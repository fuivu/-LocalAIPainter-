#!/bin/bash
# ============================================================
#  Local AI Painter v3.0 — 一键编译脚本 (Git 可用)
#  功能: 环境检测 → Wrapper 安装 → 依赖下载 → 编译 APK → 输出
#  兼容: macOS / Linux / Windows(Git Bash)
# ============================================================

set -e

# ── 颜色定义 ──────────────────────────────────────────────
if [ -t 1 ]; then
    RED='\033[0;31m'; GREEN='\033[0;32m'; YELLOW='\033[1;33m'
    BLUE='\033[0;34m'; CYAN='\033[0;36m'; BOLD='\033[1m'; NC='\033[0m'
else
    RED=''; GREEN=''; YELLOW=''; BLUE=''; CYAN=''; BOLD=''; NC=''
fi

PROJECT_ROOT="$(cd "$(dirname "$0")" && pwd)"
cd "${PROJECT_ROOT}"

# ── 日志函数 ──────────────────────────────────────────────
log_info()    { echo -e "${CYAN}[INFO]${NC}  $*"; }
log_step()    { echo -e "\n${BLUE}${BOLD}▶ $*${NC}"; }
log_ok()      { echo -e "${GREEN}✓${NC}  $*"; }
log_warn()    { echo -e "${YELLOW}⚠${NC}  $*"; }
log_error()   { echo -e "${RED}✗${NC}  $*"; }
log_section() { echo -e "\n${BOLD}${CYAN}════ $* ════${NC}"; }

# ── 横幅 ──────────────────────────────────────────────────
echo ""
echo -e "${BOLD}${BLUE}  ╔════════════════════════════════════════╗${NC}"
echo -e "${BOLD}${BLUE}  ║   Local AI Painter v3.0  Build System  ║${NC}"
echo -e "${BOLD}${BLUE}  ╚════════════════════════════════════════╝${NC}"
echo -e "  ${CYAN}Project:${NC} ${PROJECT_ROOT}"
echo -e "  ${CYAN}Date:${NC}    $(date '+%Y-%m-%d %H:%M:%S')"
echo ""

# ── Step 1: 检测系统 ─────────────────────────────────────
log_section "Step 1/6 — 系统环境检测"
OS_TYPE="$(uname -s)"
case "${OS_TYPE}" in
    Darwin*)  OS_NAME="macOS" ;;
    Linux*)   OS_NAME="Linux" ;;
    MINGW*)   OS_NAME="Windows (Git Bash)" ;;
    *)        OS_NAME="Unknown (${OS_TYPE})" ;;
esac
log_ok "操作系统: ${OS_NAME}"

# 检测架构
ARCH="$(uname -m)"
log_ok "CPU 架构: ${ARCH}"

# ── Step 2: 检测 JDK ─────────────────────────────────────
log_section "Step 2/6 — JDK 检测"
if command -v java >/dev/null 2>&1; then
    JAVA_VERSION="$(java -version 2>&1 | head -1 | sed 's/.*"\(.*\)".*/\1/')"
    log_ok "JDK 已安装: ${JAVA_VERSION}"
    # 检查版本 >= 17
    JAVA_MAJOR="$(echo "${JAVA_VERSION}" | cut -d. -f1)"
    if [ "${JAVA_MAJOR}" -lt 17 ] 2>/dev/null; then
        log_warn "JDK 版本低于 17，建议升级到 JDK 17+"
    fi
else
    log_error "未找到 Java，请先安装 JDK 17+"
    echo "  下载: https://adoptium.net/temurin/releases/?version=17"
    exit 1
fi

# ── Step 3: 检测 Android SDK ─────────────────────────────
log_section "Step 3/6 — Android SDK 检测"
if [ -z "${ANDROID_HOME}" ] && [ -z "${ANDROID_SDK_ROOT}" ]; then
    # 尝试常见路径
    for p in \
        "${HOME}/Android/Sdk" \
        "${HOME}/Library/Android/sdk" \
        "${HOME}/AppData/Local/Android/Sdk" \
        "/opt/android-sdk"; do
        if [ -d "${p}" ]; then
            export ANDROID_HOME="${p}"
            break
        fi
    done
fi

if [ -n "${ANDROID_HOME}" ] && [ -d "${ANDROID_HOME}" ]; then
    log_ok "Android SDK: ${ANDROID_HOME}"
else
    log_error "未找到 Android SDK"
    echo "  请设置环境变量: export ANDROID_HOME=/path/to/android/sdk"
    echo "  或安装 Android Studio: https://developer.android.com/studio"
    exit 1
fi

# 检查必要的 SDK 组件
if [ -d "${ANDROID_HOME}/platforms/android-34" ]; then
    log_ok "Android SDK Platform 34 ✓"
else
    log_warn "缺少 Android SDK Platform 34，尝试安装..."
    if [ -f "${ANDROID_HOME}/cmdline-tools/latest/bin/sdkmanager" ]; then
        "${ANDROID_HOME}/cmdline-tools/latest/bin/sdkmanager" "platforms;android-34"
    fi
fi

if [ -d "${ANDROID_HOME}/build-tools/34.0.0" ] || [ -d "${ANDROID_HOME}/build-tools/34.0.1" ]; then
    log_ok "Android Build Tools 34 ✓"
else
    log_warn "缺少 Build Tools 34"
fi

# ── Step 4: 检测/安装 NDK ────────────────────────────────
log_section "Step 4/6 — Android NDK 检测"
NDK_VERSION="26.1.10909125"
if [ -d "${ANDROID_HOME}/ndk/${NDK_VERSION}" ]; then
    log_ok "NDK ${NDK_VERSION} ✓"
elif [ -d "${ANDROID_HOME}/ndk" ] && [ "$(ls -A "${ANDROID_HOME}/ndk" 2>/dev/null)" ]; then
    AVAILABLE_NDK="$(ls "${ANDROID_HOME}/ndk" | head -1)"
    log_ok "使用已有 NDK: ${AVAILABLE_NDK}"
else
    log_warn "缺少 NDK，尝试安装..."
    if [ -f "${ANDROID_HOME}/cmdline-tools/latest/bin/sdkmanager" ]; then
        "${ANDROID_HOME}/cmdline-tools/latest/bin/sdkmanager" "ndk;${NDK_VERSION}"
    else
        log_warn "请手动安装 NDK: sdkmanager \"ndk;${NDK_VERSION}\""
    fi
fi

# ── Step 5: 安装 Gradle Wrapper ──────────────────────────
log_section "Step 5/6 — Gradle Wrapper 安装"
WRAPPER_JAR="${PROJECT_ROOT}/gradle/wrapper/gradle-wrapper.jar"

if [ -f "${WRAPPER_JAR}" ] && jar tf "${WRAPPER_JAR}" 2>/dev/null | grep -q "GradleWrapperMain"; then
    log_ok "gradle-wrapper.jar 已就绪"
else
    log_info "gradle-wrapper.jar 缺失，尝试安装..."
    # 尝试运行安装脚本
    if [ -f "${PROJECT_ROOT}/install-wrapper.sh" ]; then
        bash "${PROJECT_ROOT}/install-wrapper.sh"
    else
        # 尝试直接下载（如果网络可用）
        log_info "尝试从网络下载..."
        TMP_ZIP="$(mktemp -d)/gradle-8.7-bin.zip"
        if command -v curl >/dev/null 2>&1; then
            curl -L --max-time 60 -o "${TMP_ZIP}" \
                "https://services.gradle.org/distributions/gradle-8.7-bin.zip" 2>/dev/null && \
                unzip -j "${TMP_ZIP}" '*/gradle-wrapper.jar' -d "${PROJECT_ROOT}/gradle/wrapper/" && \
                log_ok "从网络下载并安装成功"
        fi
    fi
fi

# 验证 gradlew
if [ -f "${PROJECT_ROOT}/gradlew" ]; then
    chmod +x "${PROJECT_ROOT}/gradlew"
    log_ok "gradlew 可执行权限已设置"
else
    log_error "gradlew 脚本不存在！"
    exit 1
fi

# ── Step 6: 编译 APK ─────────────────────────────────────
log_section "Step 6/6 — 编译 APK"

BUILD_TYPE="${1:-release}"
case "${BUILD_TYPE}" in
    debug)   TASK="assembleDebug"   OUTPUT_DIR="debug"   ;;
    release) TASK="assembleRelease" OUTPUT_DIR="release" ;;
    *)       log_error "用法: $0 [debug|release]"; exit 1 ;;
esac

log_info "构建类型: ${BUILD_TYPE}"
log_info "Gradle 任务: ${TASK}"
echo ""

# 执行构建
START_TIME=$(date +%s)
"${PROJECT_ROOT}/gradlew" clean "${TASK}" --no-daemon --stacktrace
BUILD_RESULT=$?
END_TIME=$(date +%s)
ELAPSED=$((END_TIME - START_TIME))

if [ ${BUILD_RESULT} -eq 0 ]; then
    echo ""
    log_section "构建成功!"
    log_ok "耗时: ${ELAPSED} 秒"
    
    # 查找生成的 APK
    APK_PATH="$(find "${PROJECT_ROOT}/app/build/outputs/apk/${OUTPUT_DIR}" -name "*.apk" 2>/dev/null | head -1)"
    if [ -n "${APK_PATH}" ] && [ -f "${APK_PATH}" ]; then
        APK_SIZE="$(du -h "${APK_PATH}" | cut -f1)"
        echo ""
        echo -e "  ${BOLD}APK 文件:${NC}"
        echo -e "    路径: ${GREEN}${APK_PATH}${NC}"
        echo -e "    大小: ${CYAN}${APK_SIZE}${NC}"
        
        # 复制到项目根目录方便取用
        cp "${APK_PATH}" "${PROJECT_ROOT}/LocalAIPainter-v3.0.0-${BUILD_TYPE}.apk"
        log_ok "已复制到: ${PROJECT_ROOT}/LocalAIPainter-v3.0.0-${BUILD_TYPE}.apk"
    fi
    
    # 显示包体优化建议
    echo ""
    log_section "包体优化建议"
    echo "  • R8 已开启 fullMode (minifyEnabled=true)"
    echo "  • 仅保留 arm64-v8a ABI"
    echo "  • 使用 WebP 替代 PNG 可减少 20-30%"
    echo "  • 开启 resourceShrinking 可再减 5-10%"
    echo "  • 动态交付 (Dynamic Feature) 可拆分模型包"
    
else
    echo ""
    log_error "构建失败! 耗时: ${ELAPSED} 秒"
    echo ""
    echo "  常见解决方案:"
    echo "  1. 检查 ANDROID_HOME 指向正确的 SDK 路径"
    echo "  2. 确认 NDK 版本 >= 26"
    echo "  3. 确认 JDK 版本 >= 17"
    echo "  4. 检查网络是否能访问 Maven 仓库"
    echo "  5. 查看上方完整错误日志"
    echo ""
    echo "  重新运行: $0 ${BUILD_TYPE}"
    exit 1
fi

echo ""
echo -e "${BOLD}${GREEN}  ╔════════════════════════════════════════╗${NC}"
echo -e "${BOLD}${GREEN}  ║   🎉 Local AI Painter v3.0 构建完成!  ║${NC}"
echo -e "${BOLD}${GREEN}  ╚════════════════════════════════════════╝${NC}"
echo ""
