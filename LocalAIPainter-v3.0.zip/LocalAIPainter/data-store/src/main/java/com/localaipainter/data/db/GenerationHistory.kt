package com.localaipainter.data.db

import androidx.room.Entity
import androidx.room.PrimaryKey

/**
 * 生成历史记录 - Room Entity
 */
@Entity(tableName = "generation_history")
data class GenerationHistory(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val prompt: String,
    val negativePrompt: String,
    val modelName: String,
    val modelType: String,
    val scheduler: String,
    val steps: Int,
    val cfgScale: Float,
    val seed: Long,
    val width: Int,
    val height: Int,
    val outputPath: String,
    val thumbnailPath: String = "",
    val loras: String = "",        // JSON array of lora names
    val controlNet: String = "",   // JSON of controlnet info
    val upscaleFactor: Int = 1,
    val faceRestore: String = "",
    val generationTimeMs: Long = 0,
    val isFavorite: Boolean = false,
    val createdAt: Long = System.currentTimeMillis()
)
