package com.localaipainter.models

/**
 * 提示词模板
 */
data class PromptTemplate(
    val id: String,
    val name: String,
    val category: String,
    val prompt: String,
    val negativePrompt: String = "low quality, blurry, deformed, ugly, watermark, text, signature",
    val recommendedSteps: Int = 25,
    val recommendedCfg: Float = 7.5f,
    val recommendedResolution: String = "512x512",
    val previewPrompt: String = ""
) {
    companion object {
        fun defaultTemplates(): List<PromptTemplate> {
            return listOf(
                // ===== 人像 =====
                PromptTemplate(
                    id = "portrait_photo", name = "写实人像", category = "人像",
                    prompt = "a beautiful portrait photo of a woman, soft natural lighting, detailed eyes, shallow depth of field, bokeh background, 85mm lens, photorealistic, high detail",
                    negativePrompt = "ugly, deformed, noisy, blurry, low contrast, watermark",
                    recommendedSteps = 30, recommendedCfg = 7.0f,
                    recommendedResolution = "512x768"
                ),
                PromptTemplate(
                    id = "portrait_anime", name = "动漫人物", category = "人像",
                    prompt = "anime girl, big beautiful eyes, flowing hair, cherry blossom background, studio ghibli style, vibrant colors, detailed illustration",
                    negativePrompt = "realistic, photo, 3d, deformed, ugly",
                    recommendedSteps = 20, recommendedCfg = 7.5f,
                    recommendedResolution = "512x768"
                ),
                PromptTemplate(
                    id = "portrait_oil", name = "油画肖像", category = "人像",
                    prompt = "oil painting portrait, classical style, dramatic lighting, renaissance masterwork, rich colors, textured brushstrokes, museum quality",
                    negativePrompt = "photo, digital art, low quality, blurry",
                    recommendedSteps = 35, recommendedCfg = 8.0f,
                    recommendedResolution = "768x1024"
                ),

                // ===== 风景 =====
                PromptTemplate(
                    id = "landscape_mountain", name = "雪山日出", category = "风景",
                    prompt = "majestic snow-capped mountains at sunrise, golden light reflecting on peaks, crystal clear lake reflection, dramatic clouds, ultra detailed landscape photography",
                    negativePrompt = "people, buildings, ugly, low quality",
                    recommendedSteps = 30, recommendedCfg = 7.0f,
                    recommendedResolution = "1024x576"
                ),
                PromptTemplate(
                    id = "landscape_fantasy", name = "奇幻森林", category = "风景",
                    prompt = "enchanted fantasy forest, glowing mushrooms, ethereal light rays through ancient trees, mystical atmosphere, hyper detailed, digital painting",
                    negativePrompt = "modern, urban, photo, ugly",
                    recommendedSteps = 28, recommendedCfg = 8.0f,
                    recommendedResolution = "768x768"
                ),
                PromptTemplate(
                    id = "landscape_cyberpunk", name = "赛博朋克城市", category = "风景",
                    prompt = "cyberpunk city at night, neon lights reflecting on wet streets, flying cars, towering skyscrapers, rain, cinematic composition, blade runner aesthetic",
                    negativePrompt = "daytime, bright, natural, rural",
                    recommendedSteps = 30, recommendedCfg = 7.5f,
                    recommendedResolution = "1024x576"
                ),

                // ===== 动漫 =====
                PromptTemplate(
                    id = "anime_landscape", name = "日系风景", category = "动漫",
                    prompt = "japanese anime landscape, serene temple in mountains, cherry blossoms falling, soft pastel colors, makoto shinkai style, beautiful composition",
                    negativePrompt = "realistic, photo, 3d render, ugly",
                    recommendedSteps = 22, recommendedCfg = 7.0f,
                    recommendedResolution = "768x512"
                ),
                PromptTemplate(
                    id = "anime_mecha", name = "机甲战斗", category = "动漫",
                    prompt = "giant mecha robot standing on battlefield, weapons drawn, explosion background, dynamic pose, highly detailed mechanical design, anime style",
                    negativePrompt = "cute, chibi, peaceful, photo",
                    recommendedSteps = 25, recommendedCfg = 7.5f,
                    recommendedResolution = "768x768"
                ),

                // ===== 奇幻 =====
                PromptTemplate(
                    id = "fantasy_dragon", name = "巨龙", category = "奇幻",
                    prompt = "majestic dragon soaring above medieval castle, fire breathing, detailed scales, dramatic sky, epic fantasy art, highly detailed digital painting",
                    negativePrompt = "cute, cartoon, simple, low detail",
                    recommendedSteps = 35, recommendedCfg = 8.0f,
                    recommendedResolution = "768x768"
                ),
                PromptTemplate(
                    id = "fantasy_wizard", name = "魔法师", category = "奇幻",
                    prompt = "powerful wizard casting spell, arcane energy swirling around hands, ancient library background, glowing runes, fantasy illustration, intricate details",
                    negativePrompt = "modern, casual, low quality",
                    recommendedSteps = 30, recommendedCfg = 7.5f,
                    recommendedResolution = "512x768"
                ),

                // ===== 科幻 =====
                PromptTemplate(
                    id = "scifi_spaceship", name = "宇宙飞船", category = "科幻",
                    prompt = "futuristic spaceship in deep space, planet in background, engine glow, intricate mechanical details, cinematic lighting, sci-fi concept art",
                    negativePrompt = "fantasy, medieval, low tech",
                    recommendedSteps = 30, recommendedCfg = 7.0f,
                    recommendedResolution = "1024x512"
                ),
                PromptTemplate(
                    id = "scifi_robot", name = "人形机器人", category = "科幻",
                    prompt = "humanoid robot with expressive face, chrome body, futuristic laboratory, soft volumetric lighting, cinematic portrait, hyper realistic",
                    negativePrompt = "cartoon, anime, simple, toy",
                    recommendedSteps = 30, recommendedCfg = 6.5f,
                    recommendedResolution = "512x768"
                ),

                // ===== 美食 =====
                PromptTemplate(
                    id = "food_gourmet", name = "精致美食", category = "美食",
                    prompt = "gourmet dish plated beautifully, restaurant quality, soft diffused lighting, shallow depth of field, food photography, appetizing",
                    negativePrompt = "ugly, messy, dark, unappetizing",
                    recommendedSteps = 20, recommendedCfg = 7.0f,
                    recommendedResolution = "512x512"
                ),

                // ===== 动物 =====
                PromptTemplate(
                    id = "animal_wolf", name = "狼", category = "动物",
                    prompt = "majestic wolf howling at full moon, snowy mountain peak, detailed fur, dramatic moonlight, wildlife photography, ultra sharp",
                    negativePrompt = "cute, cartoon, deformed, low quality",
                    recommendedSteps = 25, recommendedCfg = 7.0f,
                    recommendedResolution = "768x512"
                ),

                // ===== 建筑 =====
                PromptTemplate(
                    id = "arch_modern", name = "现代建筑", category = "建筑",
                    prompt = "stunning modern architecture, glass facade, geometric design, sunset reflection, architectural photography, wide angle, award winning",
                    negativePrompt = "old, dilapidated, messy, low quality",
                    recommendedSteps = 25, recommendedCfg = 7.0f,
                    recommendedResolution = "768x1024"
                ),

                // ===== 抽象艺术 =====
                PromptTemplate(
                    id = "abstract_fluid", name = "流体艺术", category = "抽象",
                    prompt = "abstract fluid art, flowing colors, acrylic pour painting, vibrant magenta and teal, golden swirls, textured surface, artistic masterpiece",
                    negativePrompt = "figurative, realistic, photo, ugly",
                    recommendedSteps = 20, recommendedCfg = 8.5f,
                    recommendedResolution = "512x512"
                ),

                // ===== Logo 设计 =====
                PromptTemplate(
                    id = "logo_minimal", name = "极简 Logo", category = "Logo",
                    prompt = "minimalist logo design, clean geometric shapes, bold typography, white background, vector style, professional branding, simple elegant",
                    negativePrompt = "complex, cluttered, realistic, photo, 3d",
                    recommendedSteps = 15, recommendedCfg = 9.0f,
                    recommendedResolution = "512x512"
                ),

                // ===== 电影感 =====
                PromptTemplate(
                    id = "cinematic_dramatic", name = "电影感场景", category = "电影",
                    prompt = "cinematic still, dramatic lighting, film grain, anamorphic lens flare, movie color grading, epic composition, volumetric fog, 8k resolution",
                    negativePrompt = "flat lighting, amateur, low quality, cartoon",
                    recommendedSteps = 35, recommendedCfg = 7.0f,
                    recommendedResolution = "1024x432"
                )
            )
        }
    }
}
