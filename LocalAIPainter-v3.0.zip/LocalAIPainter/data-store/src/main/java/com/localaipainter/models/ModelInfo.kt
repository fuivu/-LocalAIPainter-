package com.localaipainter.models

import com.localaipainter.engine.ModelType

/**
 * 模型信息
 */
data class ModelInfo(
    val name: String,
    val path: String,
    val type: ModelType,
    val sizeMB: Long,
    val format: String, // safetensors / gguf / onnx / mnn
    val isLoaded: Boolean = false,
    val hash: String = "",
    val triggerWords: List<String> = emptyList(),
    val recommendedResolution: Int = 512,
    val minSteps: Int = 10,
    val maxSteps: Int = 50,
    val description: String = ""
)
