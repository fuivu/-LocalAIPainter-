package com.localaipainter.data.db

import androidx.lifecycle.LiveData
import androidx.room.*

@Dao
interface GenerationHistoryDao {

    @Insert
    suspend fun insert(history: GenerationHistory): Long

    @Update
    suspend fun update(history: GenerationHistory)

    @Delete
    suspend fun delete(history: GenerationHistory)

    @Query("SELECT * FROM generation_history ORDER BY createdAt DESC")
    fun getAll(): LiveData<List<GenerationHistory>>

    @Query("SELECT * FROM generation_history WHERE isFavorite = 1 ORDER BY createdAt DESC")
    fun getFavorites(): LiveData<List<GenerationHistory>>

    @Query("SELECT * FROM generation_history WHERE id = :id")
    suspend fun getById(id: Long): GenerationHistory?

    @Query("UPDATE generation_history SET isFavorite = :favorite WHERE id = :id")
    suspend fun setFavorite(id: Long, favorite: Boolean)

    @Query("SELECT * FROM generation_history WHERE createdAt >= :since ORDER BY createdAt DESC LIMIT :limit")
    suspend fun getRecent(since: Long, limit: Int): List<GenerationHistory>

    @Query("DELETE FROM generation_history WHERE id IN (:ids)")
    suspend fun deleteBatch(ids: List<Long>)

    @Query("SELECT COUNT(*) FROM generation_history")
    fun getCount(): LiveData<Int>
}
