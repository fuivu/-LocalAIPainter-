package com.localaipainter.data

import android.content.Context
import com.localaipainter.engine.*
import com.localaipainter.models.*
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import java.io.File

/**
 * 模型仓库 - 管理所有模型文件
 */
class ModelRepository(private val context: Context) {

    private val modelDir: File
        get() = File(context.getExternalFilesDir(null), "models").apply { mkdirs() }

    private val _models = MutableStateFlow<List<ModelInfo>>(emptyList())
    val models: StateFlow<List<ModelInfo>> = _models

    private val _loras = MutableStateFlow<List<LoRAModel>>(emptyList())
    val loras: StateFlow<List<LoRAModel>> = _loras

    private val _controlNets = MutableStateFlow<List<ControlNetModel>>(emptyList())
    val controlNets: StateFlow<List<ControlNetModel>> = _controlNets

    init {
        scanModels()
    }

    fun scanModels() {
        val found = mutableListOf<ModelInfo>()
        modelDir.walk().filter { it.isFile }.forEach { file ->
            when {
                file.extension == "safetensors" -> {
                    val type = detectModelType(file)
                    found.add(
                        ModelInfo(
                            name = file.nameWithoutExtension,
                            path = file.absolutePath,
                            type = type,
                            sizeMB = file.length() / (1024 * 1024),
                            format = "safetensors",
                            recommendedResolution = when (type) {
                                ModelType.SDXL -> 1024
                                else -> 512
                            }
                        )
                    )
                }
                file.extension == "gguf" -> {
                    found.add(
                        ModelInfo(
                            name = file.nameWithoutExtension,
                            path = file.absolutePath,
                            type = ModelType.SD15,
                            sizeMB = file.length() / (1024 * 1024),
                            format = "gguf"
                        )
                    )
                }
                file.extension == "onnx" -> {
                    found.add(
                        ModelInfo(
                            name = file.nameWithoutExtension,
                            path = file.absolutePath,
                            type = ModelType.SD15,
                            sizeMB = file.length() / (1024 * 1024),
                            format = "onnx"
                        )
                    )
                }
            }
        }
        _models.value = found
    }

    fun scanLoras() {
        val loraDir = File(modelDir, "lora")
        if (!loraDir.exists()) return

        val found = mutableListOf<LoRAModel>()
        loraDir.walk().filter { it.isFile && it.extension == "safetensors" }.forEach { file ->
            found.add(
                LoRAModel(
                    name = file.nameWithoutExtension,
                    path = file.absolutePath,
                    sizeMB = file.length() / (1024 * 1024)
                )
            )
        }
        _loras.value = found
    }

    fun scanControlNets() {
        val cnDir = File(modelDir, "controlnet")
        if (!cnDir.exists()) return

        val found = mutableListOf<ControlNetModel>()
        cnDir.walk().filter { it.isFile && it.extension == "safetensors" }.forEach { file ->
            val type = detectControlNetType(file.name)
            found.add(
                ControlNetModel(
                    name = file.nameWithoutExtension,
                    path = file.absolutePath,
                    type = type,
                    sizeMB = file.length() / (1024 * 1024)
                )
            )
        }
        _controlNets.value = found
    }

    private fun detectModelType(file: File): ModelType {
        val name = file.name.lowercase()
        return when {
            name.contains("xl") || name.contains("sdxl") -> ModelType.SDXL
            name.contains("2.1") || name.contains("v2") -> ModelType.SD21
            name.contains("lcm") -> ModelType.LCM
            name.contains("pixart") -> ModelType.PIXART
            name.contains("kolors") || name.contains("可灵") -> ModelType.KOLORS
            else -> ModelType.SD15
        }
    }

    private fun detectControlNetType(name: String): ControlNetType {
        val lower = name.lowercase()
        return when {
            lower.contains("canny") -> ControlNetType.CANNY
            lower.contains("pose") || lower.contains("openpose") -> ControlNetType.OPENPOSE
            lower.contains("depth") -> ControlNetType.DEPTH
            lower.contains("scribble") -> ControlNetType.SCRIBBLE
            lower.contains("mlsd") -> ControlNetType.MLSD
            lower.contains("seg") -> ControlNetType.SEG
            else -> ControlNetType.CANNY
        }
    }

    fun getModelByName(name: String): ModelInfo? {
        return _models.value.find { it.name == name }
    }

    fun importModel(sourcePath: String): Boolean {
        val source = File(sourcePath)
        if (!source.exists()) return false
        val dest = File(modelDir, source.name)
        return try {
            source.copyTo(dest, overwrite = true)
            scanModels()
            true
        } catch (e: Exception) {
            false
        }
    }

    fun deleteModel(name: String): Boolean {
        val model = getModelByName(name) ?: return false
        val file = File(model.path)
        return if (file.delete()) {
            scanModels()
            true
        } else false
    }
}
