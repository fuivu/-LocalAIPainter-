package com.localaipainter.models

import com.localaipainter.engine.ControlNetType

/**
 * ControlNet 模型信息
 */
data class ControlNetModel(
    val name: String,
    val path: String,
    val type: ControlNetType,
    val imagePath: String = "",
    val strength: Float = 0.7f,
    val isLoaded: Boolean = false,
    val sizeMB: Long = 0L,
    val description: String = ""
)
