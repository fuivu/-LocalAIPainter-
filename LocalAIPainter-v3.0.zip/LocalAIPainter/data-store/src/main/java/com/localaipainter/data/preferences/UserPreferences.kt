package com.localaipainter.data.preferences

import android.content.Context
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.*
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

private val Context.dataStore: DataStore<Preferences> by preferencesDataStore(name = "user_preferences")

class UserPreferences(context: Context) {

    private val dataStore = context.dataStore

    // ============ Keys ============

    companion object {
        val THEME = stringPreferencesKey("theme")
        val DEFAULT_MODEL = stringPreferencesKey("default_model")
        val DEFAULT_SCHEDULER = stringPreferencesKey("default_scheduler")
        val DEFAULT_STEPS = intPreferencesKey("default_steps")
        val DEFAULT_CFG = floatPreferencesKey("default_cfg")
        val DEFAULT_WIDTH = intPreferencesKey("default_width")
        val DEFAULT_HEIGHT = intPreferencesKey("default_height")
        val USE_GPU = booleanPreferencesKey("use_gpu")
        val USE_QUANTIZATION = booleanPreferencesKey("use_quantization")
        val THREAD_COUNT = intPreferencesKey("thread_count")
        val MEMORY_LIMIT_MB = intPreferencesKey("memory_limit_mb")
        val AUTO_START = booleanPreferencesKey("auto_start")
        val KEEP_SCREEN_ON = booleanPreferencesKey("keep_screen_on")
        val SAVE_METADATA = booleanPreferencesKey("save_metadata")
        val OUTPUT_FORMAT = stringPreferencesKey("output_format")
        val LAST_MODEL_PATH = stringPreferencesKey("last_model_path")
    }

    // ============ Getters ============

    val theme: Flow<String> = dataStore.data.map { it[THEME] ?: "dark" }
    val defaultModel: Flow<String> = dataStore.data.map { it[DEFAULT_MODEL] ?: "SD1.5" }
    val defaultScheduler: Flow<String> = dataStore.data.map { it[DEFAULT_SCHEDULER] ?: "Euler a" }
    val defaultSteps: Flow<Int> = dataStore.data.map { it[DEFAULT_STEPS] ?: 20 }
    val defaultCfg: Flow<Float> = dataStore.data.map { it[DEFAULT_CFG] ?: 7.5f }
    val defaultWidth: Flow<Int> = dataStore.data.map { it[DEFAULT_WIDTH] ?: 512 }
    val defaultHeight: Flow<Int> = dataStore.data.map { it[DEFAULT_HEIGHT] ?: 512 }
    val useGpu: Flow<Boolean> = dataStore.data.map { it[USE_GPU] ?: true }
    val useQuantization: Flow<Boolean> = dataStore.data.map { it[USE_QUANTIZATION] ?: true }
    val threadCount: Flow<Int> = dataStore.data.map { it[THREAD_COUNT] ?: 4 }
    val memoryLimitMB: Flow<Int> = dataStore.data.map { it[MEMORY_LIMIT_MB] ?: 4096 }
    val autoStart: Flow<Boolean> = dataStore.data.map { it[AUTO_START] ?: false }
    val keepScreenOn: Flow<Boolean> = dataStore.data.map { it[KEEP_SCREEN_ON] ?: true }
    val saveMetadata: Flow<Boolean> = dataStore.data.map { it[SAVE_METADATA] ?: true }
    val outputFormat: Flow<String> = dataStore.data.map { it[OUTPUT_FORMAT] ?: "PNG" }
    val lastModelPath: Flow<String> = dataStore.data.map { it[LAST_MODEL_PATH] ?: "" }

    // ============ Setters ============

    suspend fun setTheme(theme: String) = dataStore.edit { it[THEME] = theme }
    suspend fun setDefaultModel(model: String) = dataStore.edit { it[DEFAULT_MODEL] = model }
    suspend fun setDefaultScheduler(scheduler: String) = dataStore.edit { it[DEFAULT_SCHEDULER] = scheduler }
    suspend fun setDefaultSteps(steps: Int) = dataStore.edit { it[DEFAULT_STEPS] = steps }
    suspend fun setDefaultCfg(cfg: Float) = dataStore.edit { it[DEFAULT_CFG] = cfg }
    suspend fun setDefaultResolution(width: Int, height: Int) = dataStore.edit {
        it[DEFAULT_WIDTH] = width
        it[DEFAULT_HEIGHT] = height
    }
    suspend fun setUseGpu(enabled: Boolean) = dataStore.edit { it[USE_GPU] = enabled }
    suspend fun setUseQuantization(enabled: Boolean) = dataStore.edit { it[USE_QUANTIZATION] = enabled }
    suspend fun setThreadCount(count: Int) = dataStore.edit { it[THREAD_COUNT] = count }
    suspend fun setMemoryLimitMB(mb: Int) = dataStore.edit { it[MEMORY_LIMIT_MB] = mb }
    suspend fun setAutoStart(enabled: Boolean) = dataStore.edit { it[AUTO_START] = enabled }
    suspend fun setKeepScreenOn(enabled: Boolean) = dataStore.edit { it[KEEP_SCREEN_ON] = enabled }
    suspend fun setSaveMetadata(enabled: Boolean) = dataStore.edit { it[SAVE_METADATA] = enabled }
    suspend fun setOutputFormat(format: String) = dataStore.edit { it[OUTPUT_FORMAT] = format }
    suspend fun setLastModelPath(path: String) = dataStore.edit { it[LAST_MODEL_PATH] = path }
}
