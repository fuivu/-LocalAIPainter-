package com.localaipainter.models

/**
 * LoRA 模型信息
 */
data class LoRAModel(
    val name: String,
    val path: String,
    val weight: Float = 0.7f,
    val isLoaded: Boolean = false,
    val sizeMB: Long = 0L,
    val triggerWords: List<String> = emptyList(),
    val baseModel: String = "SD1.5",  // 兼容的基模型
    val description: String = ""
) {
    fun weightLabel(): String = String.format("%.2f", weight)
}
