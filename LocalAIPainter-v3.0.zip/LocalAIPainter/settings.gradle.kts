pluginManagement {
    repositories {
        google {
            content {
                includeGroupByRegex("com\\.android.*")
                includeGroupByRegex("com\\.google.*")
                includeGroupByRegex("androidx.*")
            }
        }
        mavenCentral()
        gradlePluginPortal()
    }
}

dependencyResolutionManagement {
    repositoriesMode.set(RepositoriesMode.FAIL_ON_PROJECT_REPOS)
    repositories {
        google()
        mavenCentral()
        maven { url = uri("https://jitpack.io") }
        // MNN 依赖
        maven { url = uri("https://maven.aliyun.com/repository/public") }
    }
}

rootProject.name = "LocalAIPainter"
include(":app")
include(":engine-core")
include(":engine-mnn")
include(":engine-ncnn")
include(":engine-onnx")
include(":ui-compose")
include(":data-store")
