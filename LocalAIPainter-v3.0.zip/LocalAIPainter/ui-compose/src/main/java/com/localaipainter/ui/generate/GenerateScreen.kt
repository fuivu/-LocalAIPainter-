package com.localaipainter.ui.generate

import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.localaipainter.engine.*
import com.localaipainter.models.PromptTemplate

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun GenerateScreen(viewModel: GenerateViewModel) {
    val prompt by viewModel.prompt.collectAsState()
    val negativePrompt by viewModel.negativePrompt.collectAsState()
    val isGenerating by viewModel.isGenerating.collectAsState()
    val progress by viewModel.progress.collectAsState()
    val currentStep by viewModel.currentStep.collectAsState()
    val totalSteps by viewModel.totalSteps.collectAsState()
    val eta by viewModel.etaSeconds.collectAsState()
    val lastOutput by viewModel.lastOutputPath.collectAsState()
    val errorMsg by viewModel.errorMessage.collectAsState()
    val config by viewModel.generationConfig.collectAsState()
    val loadedLoras by viewModel.loadedLoras.collectAsState()
    val availableLoras by viewModel.availableLoras.collectAsState()
    val templates = remember { PromptTemplate.defaultTemplates() }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("✨ 创作", fontWeight = FontWeight.Bold) },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.surface
                )
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .verticalScroll(rememberScrollState())
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            // ===== 提示词输入 =====
            Text("提示词", style = MaterialTheme.typography.titleMedium)
            OutlinedTextField(
                value = prompt,
                onValueChange = viewModel::setPrompt,
                placeholder = { Text("描述你想画的画面...") },
                modifier = Modifier.fillMaxWidth().height(100.dp),
                maxLines = 4
            )

            // ===== 提示词模板 =====
            Text("快捷模板", style = MaterialTheme.typography.titleSmall)
            LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                items(templates) { template ->
                    SuggestionChip(
                        onClick = {
                            viewModel.applyTemplate(
                                template.prompt, template.negativePrompt,
                                template.recommendedSteps, template.recommendedCfg,
                                template.recommendedResolution.split("x")[0].toInt(),
                                template.recommendedResolution.split("x")[1].toInt(),
                                SchedulerType.EULER_A
                            )
                        },
                        label = { Text(template.name, fontSize = 12.sp) }
                    )
                }
            }

            // ===== 负向提示词 =====
            Text("负向提示词", style = MaterialTheme.typography.titleSmall)
            OutlinedTextField(
                value = negativePrompt,
                onValueChange = viewModel::setNegativePrompt,
                placeholder = { Text("不想出现的内容...") },
                modifier = Modifier.fillMaxWidth().height(60.dp),
                maxLines = 2
            )

            Divider()

            // ===== 模型选择 =====
            val models by viewModel.availableModels.collectAsState()
            val selectedModel by viewModel.selectedModel.collectAsState()
            Text("模型", style = MaterialTheme.typography.titleMedium)
            LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                items(models) { model ->
                    FilterChip(
                        selected = selectedModel == model.type,
                        onClick = { viewModel.setModel(model.type) },
                        label = { Text("${model.name} (${model.sizeMB}MB)") }
                    )
                }
            }

            // ===== 采样器 =====
            val scheduler by viewModel.selectedScheduler.collectAsState()
            Text("采样器", style = MaterialTheme.typography.titleSmall)
            LazyRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                items(SchedulerType.values().toList()) { s ->
                    FilterChip(
                        selected = scheduler == s,
                        onClick = { viewModel.setScheduler(s) },
                        label = { Text(s.displayName, fontSize = 11.sp) }
                    )
                }
            }

            // ===== 高级参数 =====
            var expanded by remember { mutableStateOf(false) }
            Card(
                modifier = Modifier.fillMaxWidth(),
                onClick = { expanded = !expanded }
            ) {
                Column(modifier = Modifier.padding(12.dp)) {
                    Text(
                        "高级参数 ${if (expanded) "▼" else "▶"}",
                        style = MaterialTheme.typography.titleSmall
                    )
                    if (expanded) {
                        Spacer(Modifier.height(8.dp))
                        // 步数
                        val steps by viewModel.steps.collectAsState()
                        Text("步数: $steps")
                        Slider(
                            value = steps.toFloat(),
                            onValueChange = { viewModel.setSteps(it.toInt()) },
                            valueRange = 1f..150f,
                            steps = 29
                        )
                        // CFG
                        val cfg by viewModel.cfgScale.collectAsState()
                        Text("CFG 引导: ${String.format("%.1f", cfg)}")
                        Slider(
                            value = cfg,
                            onValueChange = { viewModel.setCfgScale(it) },
                            valueRange = 1f..30f,
                            steps = 29
                        )
                        // 分辨率
                        val w by viewModel.width.collectAsState()
                        val h by viewModel.height.collectAsState()
                        Text("分辨率: ${w}x${h}")
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            listOf(384, 512, 768, 1024).forEach { size ->
                                FilterChip(
                                    selected = w == size,
                                    onClick = { viewModel.setResolution(size, size) },
                                    label = { Text("${size}²") }
                                )
                            }
                        }
                        Spacer(Modifier.height(4.dp))
                        // 宽屏
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            listOf("512x768" to Pair(512, 768),
                                "768x512" to Pair(768, 512),
                                "1024x576" to Pair(1024, 576),
                                "576x1024" to Pair(576, 1024)
                            ).forEach { (label, wh) ->
                                FilterChip(
                                    selected = w == wh.first && h == wh.second,
                                    onClick = { viewModel.setResolution(wh.first, wh.second) },
                                    label = { Text(label, fontSize = 11.sp) }
                                )
                            }
                        }
                        Spacer(Modifier.height(8.dp))
                        // Seed
                        val seed by viewModel.seed.collectAsState()
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text("种子: ${if (seed < 0) "随机" else seed}")
                            Spacer(Modifier.width(8.dp))
                            OutlinedButton(onClick = viewModel::randomizeSeed) { Text("🎲") }
                            Spacer(Modifier.width(4.dp))
                            OutlinedButton(onClick = viewModel::resetSeed) { Text("↺") }
                        }
                        Spacer(Modifier.height(8.dp))
                        // CLIP Skip
                        val clipSkip by viewModel.clipSkip.collectAsState()
                        Text("CLIP Skip: $clipSkip")
                        Slider(
                            value = clipSkip.toFloat(),
                            onValueChange = { viewModel.setClipSkip(it.toInt()) },
                            valueRange = 1f..4f,
                            steps = 2
                        )
                        // 批量
                        val batch by viewModel.batchSize.collectAsState()
                        Text("批量: $batch")
                        Slider(
                            value = batch.toFloat(),
                            onValueChange = { viewModel.setBatchSize(it.toInt()) },
                            valueRange = 1f..8f,
                            steps = 6
                        )
                    }
                }
            }

            // ===== LoRA =====
            val loras by viewModel.loadedLoras.collectAsState()
            Text("LoRA (${loras.size}/5)", style = MaterialTheme.typography.titleSmall)
            LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                items(availableLoras) { lora ->
                    val isLoaded = loras.any { it.name == lora.name }
                    FilterChip(
                        selected = isLoaded,
                        onClick = { viewModel.toggleLora(lora) },
                        label = { Text("${lora.name} (${lora.sizeMB}MB)") }
                    )
                }
            }
            // LoRA 权重
            loras.forEach { lora ->
                Text("${lora.name}: ${lora.weightLabel()}")
                Slider(
                    value = lora.weight,
                    onValueChange = { viewModel.setLoraWeight(lora.name, it) },
                    valueRange = 0f..2f,
                    steps = 20
                )
            }

            Divider()

            // ===== 生成按钮 / 进度 =====
            if (isGenerating) {
                LinearProgressIndicator(
                    progress = progress,
                    modifier = Modifier.fillMaxWidth().height(8.dp)
                        .clip(RoundedCornerShape(4.dp))
                )
                Text(
                    "步骤 $currentStep / $totalSteps  ETA: ${eta.toInt()}s",
                    style = MaterialTheme.typography.bodySmall
                )
                Button(
                    onClick = viewModel::stopGeneration,
                    modifier = Modifier.fillMaxWidth(),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = MaterialTheme.colorScheme.error
                    )
                ) { Text("⏹ 停止生成") }
            } else {
                Button(
                    onClick = viewModel::generate,
                    modifier = Modifier.fillMaxWidth().height(56.dp),
                    enabled = prompt.isNotBlank() && !isGenerating
                ) { Text("✨ 开始生成", fontSize = 18.sp) }
            }

            // ===== 错误信息 =====
            errorMsg?.let { msg ->
                Card(
                    colors = CardDefaults.cardColors(
                        containerColor = MaterialTheme.colorScheme.errorContainer
                    )
                ) {
                    Text(
                        msg,
                        modifier = Modifier.padding(12.dp),
                        color = MaterialTheme.colorScheme.onErrorContainer
                    )
                }
            }

            // ===== 上次生成结果 =====
            lastOutput?.let { path ->
                Spacer(Modifier.height(8.dp))
                Card(modifier = Modifier.fillMaxWidth()) {
                    Column(modifier = Modifier.padding(12.dp)) {
                        Text("✅ 生成完成", fontWeight = FontWeight.Bold)
                        Text(path, style = MaterialTheme.typography.bodySmall)
                    }
                }
            }

            // ===== 配置摘要 =====
            Spacer(Modifier.height(8.dp))
            Card(modifier = Modifier.fillMaxWidth()) {
                Text(
                    config.toSummary(),
                    modifier = Modifier.padding(12.dp),
                    style = MaterialTheme.typography.bodySmall
                )
            }
        }
    }
}
