package com.localaipainter.ui.models

import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.localaipainter.models.ControlNetModel
import com.localaipainter.models.LoRAModel
import com.localaipainter.models.ModelInfo

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ModelsScreen(viewModel: ModelsViewModel) {
    val category by viewModel.category.collectAsState()
    val checkpoints by viewModel.checkpoints.collectAsState()
    val loras by viewModel.loras.collectAsState()
    val controlNets by viewModel.controlNets.collectAsState()
    val status by viewModel.importStatus.collectAsState()

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("📦 模型管理") },
                actions = {
                    IconButton(onClick = viewModel::scanAll) {
                        Text("🔄", fontSize = 18.sp)
                    }
                }
            )
        }
    ) { padding ->
        Column(modifier = Modifier.fillMaxSize().padding(padding)) {
            // 分类 Tab
            ScrollableTabRow(selectedTabIndex = category.ordinal) {
                ModelsViewModel.ModelCategory.values().forEach { cat ->
                    Tab(
                        selected = category == cat,
                        onClick = { viewModel.setCategory(cat) },
                        text = {
                            Text(when (cat) {
                                ModelsViewModel.ModelCategory.CHECKPOINT -> "Checkpoint"
                                ModelsViewModel.ModelCategory.LORA -> "LoRA"
                                ModelsViewModel.ModelCategory.CONTROLNET -> "ControlNet"
                                ModelsViewModel.ModelCategory.VAE -> "VAE"
                                ModelsViewModel.ModelCategory.EMBEDDING -> "Embedding"
                            })
                        }
                    )
                }
            }

            // 导入按钮
            Row(
                modifier = Modifier.fillMaxWidth().padding(8.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Button(
                    onClick = { /* 打开文件选择器 */ },
                    modifier = Modifier.weight(1f)
                ) { Text("📥 导入模型") }
                OutlinedButton(
                    onClick = viewModel::scanAll,
                    modifier = Modifier.weight(1f)
                ) { Text("🔍 扫描") }
            }

            // 状态提示
            status?.let { msg ->
                Card(
                    modifier = Modifier.fillMaxWidth().padding(8.dp),
                    colors = CardDefaults.cardColors(
                        containerColor = MaterialTheme.colorScheme.primaryContainer
                    )
                ) {
                    Text(msg, modifier = Modifier.padding(12.dp))
                }
            }

            // 模型列表
            when (category) {
                ModelsViewModel.ModelCategory.CHECKPOINT -> {
                    ModelList(
                        models = checkpoints,
                        onLoad = { m -> viewModel.loadModelAsActive(m.path, m.type) },
                        onDelete = { m -> viewModel.deleteModel(m.name) }
                    )
                }
                ModelsViewModel.ModelCategory.LORA -> {
                    LoRAList(
                        loras = loras,
                        onDelete = { l -> viewModel.deleteModel(l.name) }
                    )
                }
                ModelsViewModel.ModelCategory.CONTROLNET -> {
                    ControlNetList(
                        items = controlNets,
                        onDelete = { cn -> viewModel.deleteModel(cn.name) }
                    )
                }
                else -> {
                    Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                        Text("暂未实现", color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                }
            }
        }
    }
}

@Composable
private fun ModelList(
    models: List<ModelInfo>,
    onLoad: (ModelInfo) -> Unit,
    onDelete: (ModelInfo) -> Unit
) {
    LazyColumn(modifier = Modifier.fillMaxSize().padding(horizontal = 8.dp)) {
        items(models) { model ->
            Card(
                modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp),
                onClick = { onLoad(model) }
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth().padding(12.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(model.name, fontWeight = androidx.compose.ui.text.font.FontWeight.Bold)
                        Text(
                            "${model.type.displayName} | ${model.format} | ${model.sizeMB}MB",
                            fontSize = 12.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                        if (model.isLoaded) {
                            Text("✅ 已加载", fontSize = 11.sp, color = MaterialTheme.colorScheme.primary)
                        }
                    }
                    IconButton(onClick = { onDelete(model) }) {
                        Text("🗑", fontSize = 16.sp)
                    }
                }
            }
        }
    }
}

@Composable
private fun LoRAList(loras: List<LoRAModel>, onDelete: (LoRAModel) -> Unit) {
    LazyColumn(modifier = Modifier.fillMaxSize().padding(horizontal = 8.dp)) {
        items(loras) { lora ->
            Card(modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth().padding(12.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(lora.name, fontWeight = androidx.compose.ui.text.font.FontWeight.Bold)
                        Text(
                            "${lora.sizeMB}MB | ${lora.baseModel}",
                            fontSize = 12.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                        if (lora.triggerWords.isNotEmpty()) {
                            Text(
                                "触发词: ${lora.triggerWords.joinToString()}",
                                fontSize = 11.sp,
                                color = MaterialTheme.colorScheme.primary
                            )
                        }
                    }
                    IconButton(onClick = { onDelete(lora) }) {
                        Text("🗑", fontSize = 16.sp)
                    }
                }
            }
        }
    }
}

@Composable
private fun ControlNetList(items: List<ControlNetModel>, onDelete: (ControlNetModel) -> Unit) {
    LazyColumn(modifier = Modifier.fillMaxSize().padding(horizontal = 8.dp)) {
        items(items) { cn ->
            Card(modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth().padding(12.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(cn.name, fontWeight = androidx.compose.ui.text.font.FontWeight.Bold)
                        Text(
                            "${cn.type.displayName} | ${cn.sizeMB}MB",
                            fontSize = 12.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                    IconButton(onClick = { onDelete(cn) }) {
                        Text("🗑", fontSize = 16.sp)
                    }
                }
            }
        }
    }
}
