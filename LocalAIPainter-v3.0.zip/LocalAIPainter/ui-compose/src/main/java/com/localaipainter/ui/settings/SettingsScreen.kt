package com.localaipainter.ui.settings

import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.localaipainter.ui.theme.AppTheme

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SettingsScreen(viewModel: SettingsViewModel) {
    val theme by viewModel.theme.collectAsState(initial = "dark")
    val useGpu by viewModel.useGpu.collectAsState(initial = true)
    val useQuant by viewModel.useQuantization.collectAsState(initial = true)
    val threads by viewModel.threadCount.collectAsState(initial = 4)
    val memLimit by viewModel.memoryLimitMB.collectAsState(initial = 4096)
    val autoStart by viewModel.autoStart.collectAsState(initial = false)
    val keepScreen by viewModel.keepScreenOn.collectAsState(initial = true)
    val saveMeta by viewModel.saveMetadata.collectAsState(initial = true)
    val outputFmt by viewModel.outputFormat.collectAsState(initial = "PNG")
    val deviceInfo by viewModel.deviceInfo.collectAsState()

    Scaffold(
        topBar = {
            TopAppBar(title = { Text("⚙ 设置") })
        }
    ) { padding ->
        LazyColumn(
            modifier = Modifier.fillMaxSize().padding(padding),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            // ===== 设备信息 =====
            item {
                LaunchedEffect(Unit) { viewModel.refreshDeviceInfo() }
                Card(modifier = Modifier.fillMaxWidth()) {
                    Column(modifier = Modifier.padding(12.dp)) {
                        Text("📱 设备信息", style = MaterialTheme.typography.titleMedium)
                        Spacer(Modifier.height(4.dp))
                        deviceInfo?.let { d ->
                            Text("CPU: ${d.cpuModel} (${d.cpuCores} 核)", fontSize = 12.sp)
                            Text("RAM: ${d.totalRamMB}MB 可用: ${d.availableRamMB}MB", fontSize = 12.sp)
                            Text("GPU: ${if (d.hasGpu) "✅ ${d.gpuMemoryMB}MB" else "❌ 未检测到"}", fontSize = 12.sp)
                            Text("最佳后端: ${d.bestBackend}", fontSize = 12.sp)
                            Text("Android: ${d.androidVersion} (API ${d.sdkVersion})", fontSize = 12.sp)
                            Text("推荐最大分辨率: ${d.recommendedMaxResolution}px", fontSize = 12.sp)
                        } ?: Text("检测中...", fontSize = 12.sp)
                    }
                }
            }

            // ===== 主题 =====
            item {
                Text("🎨 主题", style = MaterialTheme.typography.titleMedium)
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    AppTheme.values().forEach { t ->
                        FilterChip(
                            selected = theme == t.name.lowercase(),
                            onClick = { viewModel.setTheme(t.name.lowercase()) },
                            label = { Text(t.displayName, fontSize = 11.sp) }
                        )
                    }
                }
            }

            // ===== 性能 =====
            item {
                Card(modifier = Modifier.fillMaxWidth()) {
                    Column(modifier = Modifier.padding(12.dp)) {
                        Text("⚡ 性能", style = MaterialTheme.typography.titleMedium)
                        Spacer(Modifier.height(8.dp))

                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text("GPU 加速", modifier = Modifier.weight(1f))
                            Switch(checked = useGpu, onCheckedChange = viewModel::setUseGpu)
                        }
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text("GPU 量化 (减少显存)", modifier = Modifier.weight(1f))
                            Switch(checked = useQuant, onCheckedChange = viewModel::setUseQuantization)
                        }

                        Text("线程数: $threads")
                        Slider(
                            value = threads.toFloat(),
                            onValueChange = { viewModel.setThreadCount(it.toInt()) },
                            valueRange = 1f..8f,
                            steps = 6
                        )

                        Text("内存上限: ${memLimit}MB")
                        Slider(
                            value = memLimit.toFloat(),
                            onValueChange = { viewModel.setMemoryLimitMB(it.toInt()) },
                            valueRange = 1024f..16384f,
                            steps = 14
                        )
                    }
                }
            }

            // ===== 系统 =====
            item {
                Card(modifier = Modifier.fillMaxWidth()) {
                    Column(modifier = Modifier.padding(12.dp)) {
                        Text("📋 系统", style = MaterialTheme.typography.titleMedium)
                        Spacer(Modifier.height(8.dp))

                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text("开机自启", modifier = Modifier.weight(1f))
                            Switch(checked = autoStart, onCheckedChange = viewModel::setAutoStart)
                        }
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text("保持屏幕常亮", modifier = Modifier.weight(1f))
                            Switch(checked = keepScreen, onCheckedChange = viewModel::setKeepScreenOn)
                        }
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text("保存生成元数据", modifier = Modifier.weight(1f))
                            Switch(checked = saveMeta, onCheckedChange = viewModel::setSaveMetadata)
                        }

                        Spacer(Modifier.height(8.dp))
                        Text("输出格式: $outputFmt", fontSize = 12.sp)
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            listOf("PNG", "JPEG", "WEBP").forEach { fmt ->
                                FilterChip(
                                    selected = outputFmt == fmt,
                                    onClick = { viewModel.setOutputFormat(fmt) },
                                    label = { Text(fmt, fontSize = 11.sp) }
                                )
                            }
                        }
                    }
                }
            }

            // ===== 导出日志 =====
            item {
                Button(
                    onClick = {
                        val log = viewModel.exportLog()
                        // 保存到文件
                    },
                    modifier = Modifier.fillMaxWidth()
                ) { Text("📤 导出日志") }
            }

            // ===== 关于 =====
            item {
                Card(modifier = Modifier.fillMaxWidth()) {
                    Column(modifier = Modifier.padding(12.dp)) {
                        Text("关于", style = MaterialTheme.typography.titleMedium)
                        Spacer(Modifier.height(4.dp))
                        Text("Local AI Painter v3.0", fontSize = 12.sp)
                        Text("完全本地运行，无需联网", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        Text("支持 SD1.5/2.1/SDXL/LCM/PixArt/Kolors", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        Text("后端: MNN + NCNN + ONNX Runtime", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                }
            }
        }
    }
}
