package com.localaipainter.ui.gallery

import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.*
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.localaipainter.data.db.GenerationHistory

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun GalleryScreen(viewModel: GalleryViewModel) {
    val filter by viewModel.filter.collectAsState()
    val items by viewModel.displayedHistory.collectAsState()
    val selected by viewModel.selectedIds.collectAsState()

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("🖼 画廊 (${items.size})") },
                actions = {
                    if (selected.isNotEmpty()) {
                        TextButton(onClick = viewModel::deleteSelected) {
                            Text("删除 (${selected.size})", color = MaterialTheme.colorScheme.error)
                        }
                        TextButton(onClick = viewModel::clearSelection) { Text("取消") }
                    }
                }
            )
        }
    ) { padding ->
        Column(modifier = Modifier.fillMaxSize().padding(padding)) {
            // 过滤器
            LazyRow(
                modifier = Modifier.padding(horizontal = 8.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                items(GalleryViewModel.FilterMode.values().toList()) { mode ->
                    val label = when (mode) {
                        GalleryViewModel.FilterMode.ALL -> "全部"
                        GalleryViewModel.FilterMode.FAVORITES -> "⭐ 收藏"
                        GalleryViewModel.FilterMode.RECENT -> "🕐 最近"
                    }
                    FilterChip(
                        selected = filter == mode,
                        onClick = { viewModel.setFilter(mode) },
                        label = { Text(label) }
                    )
                }
            }

            if (items.isEmpty()) {
                Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                    Text("暂无图片，去创作吧！", color = Color.Gray)
                }
            } else {
                LazyVerticalGrid(
                    columns = GridCells.Adaptive(minSize = 150.dp),
                    modifier = Modifier.fillMaxSize().padding(4.dp),
                    horizontalArrangement = Arrangement.spacedBy(4.dp),
                    verticalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    items(items.size) { idx ->
                        val item = items[idx]
                        GalleryItem(
                            item = item,
                            isSelected = selected.contains(item.id),
                            onClick = { viewModel.toggleSelection(item.id) },
                            onLongClick = { viewModel.toggleFavorite(item.id) },
                            onDelete = { viewModel.deleteItem(item.id) }
                        )
                    }
                }
            }
        }
    }
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
private fun GalleryItem(
    item: GenerationHistory,
    isSelected: Boolean,
    onClick: () -> Unit,
    onLongClick: () -> Unit,
    onDelete: () -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .aspectRatio(1f)
            .combinedClickable(onClick = onClick, onLongClick = onLongClick),
        border = if (isSelected) BorderStroke(2.dp, MaterialTheme.colorScheme.primary) else null
    ) {
        Box {
            if (item.outputPath.isNotEmpty()) {
                AsyncImage(
                    model = item.outputPath,
                    contentDescription = item.prompt,
                    modifier = Modifier.fillMaxSize(),
                    contentScale = ContentScale.Crop
                )
            } else {
                Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                    Text("无预览", fontSize = 12.sp, color = Color.Gray)
                }
            }

            // 收藏标记
            if (item.isFavorite) {
                Text(
                    "⭐", modifier = Modifier.align(Alignment.TopStart).padding(4.dp),
                    fontSize = 14.sp
                )
            }

            // 选中标记
            if (isSelected) {
                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = MaterialTheme.colorScheme.primary.copy(alpha = 0.3f)
                ) {}
            }

            // 删除按钮
            TextButton(
                onClick = onDelete,
                modifier = Modifier.align(Alignment.BottomEnd).padding(2.dp)
            ) {
                Text("🗑", fontSize = 12.sp)
            }
        }
    }
}
