package com.localaipainter.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.graphics.Color

// ============ 颜色方案 ============

private val DarkColorScheme = darkColorScheme(
    primary = Color(0xFF7C4DFF),
    onPrimary = Color.White,
    primaryContainer = Color(0xFF3F2B96),
    onPrimaryContainer = Color(0xFFE8DEFF),
    secondary = Color(0xFF00BCD4),
    onSecondary = Color.Black,
    secondaryContainer = Color(0xFF004F54),
    onSecondaryContainer = Color(0xFFAAF0F5),
    tertiary = Color(0xFFFF6E40),
    onTertiary = Color.Black,
    background = Color(0xFF0F0F1A),
    onBackground = Color(0xFFE0E0E0),
    surface = Color(0xFF1A1A2E),
    onSurface = Color(0xFFE0E0E0),
    surfaceVariant = Color(0xFF2A2A4A),
    onSurfaceVariant = Color(0xFFCACADD),
    error = Color(0xFFFF5252),
    onError = Color.Black
)

private val LightColorScheme = lightColorScheme(
    primary = Color(0xFF6200EE),
    onPrimary = Color.White,
    primaryContainer = Color(0xFFE8DEFF),
    onPrimaryContainer = Color(0xFF3F2B96),
    secondary = Color(0xFF00838F),
    onSecondary = Color.White,
    secondaryContainer = Color(0xFFAAF0F5),
    onSecondaryContainer = Color(0xFF004F54),
    tertiary = Color(0xFFE64A19),
    onTertiary = Color.White,
    background = Color(0xFFFAFAFA),
    onBackground = Color(0xFF1A1A1A),
    surface = Color.White,
    onSurface = Color(0xFF1A1A1A),
    surfaceVariant = Color(0xFFF0F0F5),
    onSurfaceVariant = Color(0xFF444458),
    error = Color(0xFFD32F2F),
    onError = Color.White
)

// AMOLED 纯黑主题
private val AmoledColorScheme = darkColorScheme(
    primary = Color(0xFFBB86FC),
    onPrimary = Color.Black,
    background = Color.Black,
    onBackground = Color.White,
    surface = Color(0xFF0A0A0A),
    onSurface = Color.White,
    secondary = Color(0xFF03DAC6),
    onSecondary = Color.Black,
    tertiary = Color(0xFFFF6E40),
    onTertiary = Color.Black
)

// 日落主题
private val SunsetColorScheme = darkColorScheme(
    primary = Color(0xFFFF6E40),
    onPrimary = Color.Black,
    background = Color(0xFF1A0E0A),
    onBackground = Color(0xFFFFE0B2),
    surface = Color(0xFF2D1810),
    onSurface = Color(0xFFFFE0B2),
    secondary = Color(0xFFFFAB40),
    onSecondary = Color.Black,
    tertiary = Color(0xFFE53935),
    onTertiary = Color.White
)

// 深海主题
private val DeepSeaColorScheme = darkColorScheme(
    primary = Color(0xFF00BCD4),
    onPrimary = Color.Black,
    background = Color(0xFF001A1A),
    onBackground = Color(0xFFB2EBF2),
    surface = Color(0xFF002A2A),
    onSurface = Color(0xFFB2EBF2),
    secondary = Color(0xFF009688),
    onSecondary = Color.White,
    tertiary = Color(0xFF3F51B5),
    onTertiary = Color.White
)

// 森林主题
private val ForestColorScheme = darkColorScheme(
    primary = Color(0xFF4CAF50),
    onPrimary = Color.Black,
    background = Color(0xFF0A1A0A),
    onBackground = Color(0xFFC8E6C9),
    surface = Color(0xFF1A2A1A),
    onSurface = Color(0xFFC8E6C9),
    secondary = Color(0xFF8BC34A),
    onSecondary = Color.Black,
    tertiary = Color(0xFF795548),
    onTertiary = Color.White
)

// ============ 主题枚举 ============

enum class AppTheme(val displayName: String) {
    DARK("深色"),
    LIGHT("浅色"),
    AMOLED("AMOLED"),
    SUNSET("日落"),
    DEEP_SEA("深海"),
    FOREST("森林")
}

@Composable
fun LocalAIPainterTheme(
    theme: AppTheme = AppTheme.DARK,
    dynamicColor: Boolean = false,
    content: @Composable () -> Unit
) {
    val colorScheme = when (theme) {
        AppTheme.DARK -> DarkColorScheme
        AppTheme.LIGHT -> LightColorScheme
        AppTheme.AMOLED -> AmoledColorScheme
        AppTheme.SUNSET -> SunsetColorScheme
        AppTheme.DEEP_SEA -> DeepSeaColorScheme
        AppTheme.FOREST -> ForestColorScheme
    }

    MaterialTheme(
        colorScheme = colorScheme,
        typography = Typography,
        content = content
    )
}
