package com.localaipainter.ui.navigation

import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.painterResource
import androidx.navigation.compose.*
import com.localaipainter.ui.gallery.GalleryViewModel
import com.localaipainter.ui.generate.GenerateViewModel
import com.localaipainter.ui.models.ModelsViewModel
import com.localaipainter.ui.settings.SettingsViewModel
import com.localaipainter.ui.generate.GenerateScreen
import com.localaipainter.ui.gallery.GalleryScreen
import com.localaipainter.ui.models.ModelsScreen
import com.localaipainter.ui.settings.SettingsScreen

sealed class Screen(val route: String, val label: String, val iconRes: String) {
    object Create : Screen("create", "创作", "✨")
    object Gallery : Screen("gallery", "画廊", "🖼")
    object Models : Screen("models", "模型", "📦")
    object Settings : Screen("settings", "设置", "⚙")
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AppNavigation(
    generateViewModel: GenerateViewModel,
    galleryViewModel: GalleryViewModel,
    modelsViewModel: ModelsViewModel,
    settingsViewModel: SettingsViewModel
) {
    val navController = rememberNavController()

    val items = listOf(
        Screen.Create, Screen.Gallery, Screen.Models, Screen.Settings
    )

    Scaffold(
        bottomBar = {
            NavigationBar {
                val currentRoute = navController.currentBackStackEntryAsState().value?.destination?.route
                items.forEach { screen ->
                    NavigationBarItem(
                        icon = { Text(screen.iconRes, style = MaterialTheme.typography.titleMedium) },
                        label = { Text(screen.label) },
                        selected = currentRoute == screen.route,
                        onClick = {
                            navController.navigate(screen.route) {
                                popUpTo(navController.graph.startDestinationId)
                                launchSingleTop = true
                            }
                        }
                    )
                }
            }
        }
    ) { padding ->
        NavHost(
            navController = navController,
            startDestination = Screen.Create.route,
            modifier = Modifier.padding(padding)
        ) {
            composable(Screen.Create.route) {
                GenerateScreen(viewModel = generateViewModel)
            }
            composable(Screen.Gallery.route) {
                GalleryScreen(viewModel = galleryViewModel)
            }
            composable(Screen.Models.route) {
                ModelsScreen(viewModel = modelsViewModel)
            }
            composable(Screen.Settings.route) {
                SettingsScreen(viewModel = settingsViewModel)
            }
        }
    }
}
