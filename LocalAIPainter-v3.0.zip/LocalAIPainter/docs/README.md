# Local AI Painter - 架构文档

## 项目结构

```
LocalAIPainter/
├── AndroidManifest.xml          # 应用清单
├── build.gradle.kts             # 根构建配置
├── settings.gradle.kts          # 项目设置
├── gradle.properties            # Gradle 属性
├── LICENSE                      # MIT 许可证
├── README.md                    # 项目说明
│
├── app/
│   ├── build.gradle.kts         # App 模块配置
│   ├── proguard-rules.pro      # 混淆规则
│   └── src/main/
│       ├── AndroidManifest.xml
│       ├── java/com/localaipainter/
│       │   ├── App.kt                     # Application 入口
│       │   │
│       │   ├── core/                      # 核心引擎层
│       │   │   ├── InferenceEngine.kt     # 统一接口
│       │   │   ├── EngineFactory.kt       # 引擎工厂
│       │   │   ├── DeviceDetector.kt      # 设备检测
│       │   │   ├── MemoryManager.kt       # 内存管理
│       │   │   ├── LruTensorCache.kt      # LRU 缓存
│       │   │   └── engine/                # 6 种推理后端
│       │   │       ├── QnnEngine.kt       # 骁龙 NPU
│       │   │       ├── MnnEngine.kt       # 阿里 MNN
│       │   │       ├── NcnnEngine.kt      # Tencent NCNN
│       │   │       ├── OnnxEngine.kt      # ONNX Runtime
│       │   │       ├── VulkanEngine.kt    # Vulkan Compute
│       │   │       └── CpuEngine.kt       # CPU 降级
│       │   │
│       │   ├── pipeline/                  # SD 管线
│       │   │   ├── SDPipeline.kt         # 主控管线
│       │   │   ├── TextEncoder.kt        # CLIP 文本编码
│       │   │   ├── Unet.kt               # UNet 去噪
│       │   │   └── VaeDecoder.kt         # VAE 解码
│       │   │
│       │   ├── scheduler/                # 7 种采样器
│       │   │   ├── Scheduler.kt          # 接口
│       │   │   ├── SchedulerFactory.kt   # 工厂
│       │   │   ├── LCMScheduler.kt       # 最快(4-8步)
│       │   │   ├── EulerAScheduler.kt    # 经典随机
│       │   │   ├── DPMPlusPlus2MScheduler.kt    # 高质量
│       │   │   ├── DPMPlusPlus2MKarrasScheduler.kt # Karras 调度
│       │   │   ├── DDIMScheduler.kt      # 确定性
│       │   │   ├── LMSScheduler.kt       # 多步线性
│       │   │   ├── HeunScheduler.kt      # 二阶精确
│       │   │   └── UniPCScheduler.kt     # 统一预测校正
│       │   │
│       │   ├── quantize/                 # 量化系统
│       │   │   ├── LocalQuantizer.kt     # 接口
│       │   │   ├── MinMaxQuantizer.kt   # INT8 Min-Max
│       │   │   ├── KLQuantizer.kt        # INT8 KL散度
│       │   │   └── GroupWiseQuantizer.kt # INT4 分组
│       │   │
│       │   ├── lora/                     # LoRA 管理
│       │   │   ├── LoraWeight.kt        # 数据类
│       │   │   └── LoraManager.kt       # 加载/堆叠/缩放
│       │   │
│       │   ├── data/                     # 数据层
│       │   │   ├── AppDatabase.kt       # Room 数据库
│       │   │   ├── entity/              # 数据实体
│       │   │   ├── dao/                 # 数据访问
│       │   │   └── repository/          # 仓库封装
│       │   │
│       │   ├── service/                 # 后台服务
│       │   │   ├── GenerationForegroundService.kt  # 前台保活
│       │   │   ├── GenerationWorker.kt            # WorkManager
│       │   │   ├── ModelDownloadService.kt        # 模型下载
│       │   │   └── BootCompletedReceiver.kt       # 开机自启
│       │   │
│       │   └── ui/                      # 界面层
│       │       ├── MainActivity.kt       # 主入口
│       │       ├── HomeScreen.kt        # 绘画界面
│       │       ├── GalleryScreen.kt     # 画廊
│       │       ├── ModelManagerScreen.kt# 模型管理
│       │       ├── SettingsScreen.kt    # 设置
│       │       └── HomeViewModel.kt     # 状态管理
│       │
│       ├── cpp/                        # C++ 原生代码
│       │   ├── CMakeLists.txt
│       │   ├── jni_bridge.cpp          # JNI 入口
│       │   ├── sd_pipeline.cpp         # SD 管线 C++
│       │   ├── text_encoder.cpp        # CLIP 编码
│       │   ├── unet.cpp                # UNet 推理
│       │   ├── vae_decoder.cpp         # VAE 解码
│       │   ├── scheduler_*.cpp         # 调度器 C++
│       │   ├── quantize_*.cpp          # 量化 C++
│       │   ├── memory_pool.cpp         # 内存池
│       │   ├── lora_loader.cpp         # LoRA 加载
│       │   ├── math_utils.cpp          # 数学工具
│       │   └── image_utils.cpp         # 图像处理
│       │
│       └── res/                        # 资源文件
│           ├── layout/
│           ├── menu/
│           ├── values/
│           ├── drawable/
│           └── xml/
│
├── scripts/                           # Python 工具
│   ├── convert_to_onnx.py            # HF → ONNX
│   └── quantize_model.py            # 模型量化
│
├── .github/workflows/                # CI/CD
│   └── build.yml                    # 自动编译 APK
│
└── docs/                            # 文档
    └── README.md                   # 本文件
```

## 推理流程

```
用户输入提示词
    ↓
[TextEncoder] 提示词 → 文本嵌入向量 (768维)
    ↓
[初始化] 随机噪声 latents (4×64×64)
    ↓
[迭代去噪] 重复 N 步:
    ├── [UNet] 预测噪声
    ├── [CFG] 条件和无条件组合
    └── [Scheduler] 更新 latents
    ↓
[VAE Decoder] latents → RGB 图像 (3×512×512)
    ↓
保存到相册 / 显示
```

## 引擎选择优先级

```
骁龙 8 Gen2+  → QNN (Hexagon NPU) ← 最快
联发科天玑9000+ → MNN (GPU) / NCNN (Vulkan)
有 Vulkan 的 GPU → NCNN / Vulkan Compute
低端设备       → ONNX Runtime (CPU)
终极降级       → 纯 CPU + INT4 量化 + 小分辨率
```

## 内存策略

| 策略 | RAM 要求 | 分辨率 | 量化 | 缓存 |
|------|---------|--------|------|------|
| 均衡 | ≥8GB | 768px | FP32 | 大 |
| 保守 | ≥4GB | 512px | INT8 | 中 |
| 极限 | ≥2GB | 384px | INT4 | 小 |
| 最低 | <2GB | 256px | INT4 | 无 |

## 编译

Push 到 GitHub 后自动触发 Actions 编译，产物在 Artifacts 中下载。
