# Local AI Painter v3.0

> 本地运行的 Android AI 绘画应用，对标 Local Dream，功能全面升级。

## ✨ 功能特性

### 核心引擎
- **6 种模型架构**：SD1.5 / SD2.1 / SDXL / LCM / PixArt / Kolors
- **5 后端异构推理**：QNN (NPU) / MNN / NCNN / ORT (Vulkan) / CPU
- **14 种采样器**：Euler A, DPM++ 2M Karras, UniPC, LCM, Heun, DPM2, DPM2 A, LMS, Euler, DDIM, PNDM, DEIS, DPM++ SDE, Restart
- **5 路 LoRA 叠加**：独立权重 0~2.0，自动拼合触发词
- **6 种 ControlNet**：Canny / OpenPose / Depth / Scribble / MLSD / Seg
- **3 种超分引擎**：ESRGAN / SwinIR / RealESRGAN（分块羽化处理大图）
- **3 种人脸修复**：GFPGAN / CodeFormer / RestoreFormer

### C++ 引擎层
- NEON SIMD 加速 GEMM / GELU / SiLU / LayerNorm
- INT8 / INT4 量化推理
- FFT 快速卷积
- Arena 内存分配器（零碎片）
- GPU 缓冲池 + 张量 LRU 缓存
- 统一内存管理（CPU/GPU/DMA/共享）

### UI 层 (Jetpack Compose)
- **创作页**：提示词输入 + 18 个快捷模板 + 高级参数面板
- **画廊页**：网格展示 + 收藏/最近筛选 + 多选批量操作
- **模型页**：5 分类管理 + 导入/扫描/删除
- **设置页**：6 套主题 + 性能调优 + 日志导出
- **6 套主题**：深色 / 浅色 / AMOLED / 日落 / 深海 / 森林

### 数据层
- Room 数据库（生成历史持久化）
- DataStore 偏好设置（14 项用户配置）
- 模型仓库（自动扫描 + 格式识别）

## 📦 项目结构

```
LocalAIPainter/
├── app/                          # 主应用模块
│   ├── src/main/
│   │   ├── cpp/                 # C++ 引擎源码 (19 个文件)
│   │   │   ├── CMakeLists.txt
│   │   │   ├── engine_factory.cpp
│   │   │   ├── tensor_ops.cpp
│   │   │   ├── simd_ops.cpp
│   │   │   ├── fft_conv.cpp
│   │   │   ├── quant_ops.cpp
│   │   │   ├── arena_allocator.cpp
│   │   │   ├── gpu_buffer_pool.cpp
│   │   │   ├── tensor_cache.cpp
│   │   │   ├── unified_memory.cpp
│   │   │   ├── image_io.cpp
│   │   │   ├── resizer.cpp
│   │   │   ├── color_space.cpp
│   │   │   ├── upscaler.cpp
│   │   │   ├── scheduler.cpp
│   │   │   ├── lora_manager.cpp
│   │   │   ├── controlnet.cpp
│   │   │   ├── post_processor.cpp
│   │   │   ├── model_loader.cpp
│   │   │   ├── vae.cpp
│   │   │   ├── clip_encoder.cpp
│   │   │   ├── t5_encoder.cpp
│   │   │   └── jni_bridge.cpp
│   │   ├── kotlin/.../engine/   # Kotlin 引擎层
│   │   ├── kotlin/.../data/     # 数据层
│   │   ├── kotlin/.../ui/       # Compose UI
│   │   └── res/                 # Android 资源
│   └── build.gradle.kts
├── gradle/wrapper/               # Gradle Wrapper
├── git-hooks/                    # Git 钩子
├── .github/workflows/            # CI/CD
├── install-wrapper.sh            # Wrapper 安装脚本
├── build-apk.sh                  # Linux/macOS 编译脚本
├── build-apk.ps1                 # Windows 编译脚本
├── setup-git-repo.sh             # Git 仓库初始化
├── .gitignore
└── README.md
```

## 🛠️ 编译指南

### 环境要求
- **JDK 17+**
- **Android SDK 34+**
- **Android NDK 26+**
- **Gradle 8.7**（Wrapper 自动管理）
- **操作系统**：Windows 10+ / macOS 12+ / Linux (Ubuntu 20.04+)

### 快速开始

#### 1. 克隆/下载项目
```bash
git clone <your-repo-url> LocalAIPainter
cd LocalAIPainter
```

#### 2. 安装 Gradle Wrapper
```bash
# 将已下载的 gradle-8.7-bin.zip 放到项目根目录
# 然后运行:
bash install-wrapper.sh

# 或手动:
gradle wrapper --gradle-version 8.7
```

#### 3. 编译 APK

**Linux / macOS:**
```bash
# Debug 版（快速编译，不混淆）
./build-apk.sh debug

# Release 版（混淆优化，目标 30-50MB）
./build-apk.sh release
```

**Windows (PowerShell):**
```powershell
# Debug 版
.\build-apk.ps1 -BuildType debug

# Release 版
.\build-apk.ps1 -BuildType release
```

**手动编译:**
```bash
# 确保 ANDROID_HOME 已设置
export ANDROID_HOME=/path/to/android/sdk

# 编译
./gradlew clean assembleRelease --no-daemon

# APK 输出位置
# app/build/outputs/apk/release/app-release-unsigned.apk
```

### 包体优化策略

| 策略 | 预期效果 |
|------|----------|
| R8 fullMode + 混淆 | -30~40% |
| 仅 arm64-v8a | -40~50% |
| 资源缩减 (shrinkResources) | -5~10% |
| WebP 替代 PNG | -20~30% |
| 动态交付 (Dynamic Feature) | 拆分模型包 |
| **合计目标** | **30-50MB** |

## 📋 Git 工作流

### 初始化仓库
```bash
bash setup-git-repo.sh https://github.com/yourname/LocalAIPainter.git
```

### 日常开发
```bash
# 查看状态
git status

# 添加改动
git add .

# 提交（自动触发 pre-commit 检查）
git commit -m "feat: 新增 XX 功能"

# 推送
git push

# 打版本标签（触发 CI 自动发布）
git tag v3.0.1
git push --tags
```

### pre-commit 钩子自动检查
- ✅ Kotlin 大括号匹配
- ✅ C++ 头文件引用完整性
- ✅ XML 资源文件有效性
- ✅ 关键文件存在性
- ✅ 版本号一致性

## 🔄 CI/CD (GitHub Actions)

推送代码后自动触发：
- **Push to main/develop** → 自动编译 Debug APK → 上传为 Artifact
- **Push tag v\*** → 自动编译 Release APK → 发布 GitHub Release

### 配置密钥（Release 签名）
在 GitHub 仓库 Settings → Secrets 中添加：
- `KEYSTORE_BASE64` — keystore 文件的 Base64 编码
- `KEYSTORE_PASSWORD` — keystore 密码
- `KEY_ALIAS` — 密钥别名
- `KEY_PASSWORD` — 密钥密码

```bash
# 生成 base64
base64 -i my-release-key.jks | tr -d '\n' > keystore_base64.txt
```

## 📊 性能基准

| 设备等级 | 芯片示例 | 512×512 出图 | 768×768 出图 |
|----------|----------|-------------|-------------|
| 旗舰 (NPU) | 骁龙 8 Gen 3 | ~8s | ~20s |
| 高端 (GPU) | 骁龙 888 | ~15s | ~40s |
| 中端 (GPU) | 天玑 8200 | ~25s | ~60s |
| 入门 (CPU) | 骁龙 695 | ~90s | ~180s |

## 📝 许可证

MIT License

## 🙏 致谢

- [Stable Diffusion](https://github.com/CompVis/stable-diffusion) — 基础模型架构
- [NCNN](https://github.com/Tencent/ncnn) — 腾讯开源推理框架
- [MNN](https://github.com/alibaba/MNN) — 阿里开源推理框架
- [Compose Multiplatform](https://www.jetbrains.com/lm/compose-multiplatform/) — UI 框架
- [Local Dream](https://github.com/) — 对标参考应用
